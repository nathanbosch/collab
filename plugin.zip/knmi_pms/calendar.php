<?php

//Build post type
function calendar_post_type() {
	$labels = array(
	  'name' => _x('Calendar', 'Cpost type general name'),
	  'singular_name' => _x('Event', 'Cpost type singular name'),
	  'add_new' => _x('Add new', 'Event'),
	  'add_new_item' => __('Add new event'),
	  'edit_item' => __('Edit event'),
	  'new_item' => __('New event'),
	  'view_item' => __('View event'),
	  'search_items' => __('Find event'),
	  'not_found' =>  __('No event found'),
	  'not_found_in_trash' => __('No event found in bin')
	);
	$args = array(
	  'labels' => $labels,
	  'public' => true,
	  'publicly_queryable' => true,
	  'show_ui' => true,
	  'exclude_from_search' => false,
	  'query_var' => true,
	  'rewrite' => array( 'slug' => 'event' ),
        'capabilities' => array(
            'edit_post' => 'edit_event',
            'edit_posts' => 'edit_events',
            'edit_others_posts' => 'edit_other_events',
            'publish_posts' => 'publish_events',
            'read_post' => 'read_event',
            'read_private_posts' => 'read_private_events',
            'delete_post' => 'delete_event'
        ),
	  'hierarchical' => false,
	  'menu_position' => 20,
      'menu_icon' => 'dashicons-calendar-alt',
	  'supports' => array('title','editor'),
      'register_meta_box_cb' => 'calendar_add_custom_metaboxes'
	);
	register_post_type('calendar',$args);
	
	
}
add_action( 'init', 'calendar_post_type' );

//Metaboxes of post type
function calendar_add_custom_metaboxes() {
    add_meta_box('calendar_metaboxes', 'Event options', 'calendar_custom_metabox_html', 'calendar', 'side', 'core');
    add_meta_box('calendar_metaboxes_files', 'Attached files', 'news_custom_metabox_html_files', 'calendar', 'normal', 'core');
}

//Meta box HTML
function calendar_custom_metabox_html() {
    global $post;
    
    // Noncename needed to verify where the data originated
	echo '<input type="hidden" name="meta_noncename" id="meta_noncename" value="' . 
	wp_create_nonce( plugin_basename(__FILE__) ) . '" />';
    
    $valid_options = array( 'street' => 'Street',
                            'number' => 'Number',
                            'city' => 'City',
                            'country' => 'Country',
                            'start_date' => 'Start date',
                            'end_date' => 'End date',
                            'start_time' => 'Start time',
                            'end_time' => 'End time');
    
    $data= array();
                           
    foreach($valid_options as $valid_option => $value){
        $data[$valid_option] = get_post_meta($post->ID, $valid_option, true);
    }
    
    
    foreach($valid_options as $valid_option => $value){
        //Determine type    
        $type = get_input_type($valid_option);
        
        echo "<span><label>{$value}</label><input type='{$type}' id='{$valid_option}' value='{$data[$valid_option]}' name='{$valid_option}'></span>";
    }
    
    
}



//Meta box save-ing
function calendar_save_custom_meta($post_id, $post) {
    //Check user level
	if ( !current_user_can( 'edit_post', $post->ID ))
		return $post->ID;
    
    $start_date = new DateTime($_POST['start_date']);
    $start_date = $start_date->format('Y-m-d');
    $end_date = new DateTime($_POST['end_date']);
    $end_date = $end_date->format('Y-m-d');
    $start_time = new DateTime();
    $start_time->setTimestamp(strtotime($_POST['start_time']));
    $start_time = $start_time->format('H:i');
    $end_time = new DateTime($end_time);
    $end_time->setTimestamp(strtotime($_POST['end_time']));
    $end_time = $end_time->format('H:i');

    update_post_meta($post->ID, 'start_date', $start_date);
    update_post_meta($post->ID, 'end_date', $end_date);
    update_post_meta($post->ID, 'start_time', $start_time);
    update_post_meta($post->ID, 'end_time', $end_time);
    update_post_meta($post->ID, 'street', $_POST['street']);
    update_post_meta($post->ID, 'number', $_POST['number']);
    update_post_meta($post->ID, 'city', $_POST['city']);
    update_post_meta($post->ID, 'country', $_POST['country']);
    update_post_meta($post->ID, 'project_id', $_SESSION['current_project_id']);    
}
add_action('save_post', 'calendar_save_custom_meta', 1, 2); // save the custom fields

//Custom table columns
function calendar_custom_column($cols) {
    $new = array();
    foreach($cols as $key => $title) {
        if ($key=='date'){
            $new['adress'] = __('Adress');
            $new['event_start_date'] = __('Start date');
            $new['event_end_date'] = __('End date');
            $new['event_time'] = __('Event time');
            $new['project'] = __('Assigned to project');
        }
        $new[$key] = $title;
    }
    return $new;
}

//The custom columns
function calendar_custom_value($column_name, $post_id) {
    $project = new project;
    
    //The functie
    if($column_name == 'adress'){
        echo get_post_meta($post_id, "street", true).' '.get_post_meta($post_id, "number", true).' '.get_post_meta($post_id, "city", true).' '.get_post_meta($post_id, "country", true); 
    }
    if($column_name == 'event_start_date'){
        echo get_post_meta($post_id, "start_date", true);
    }
    if($column_name == 'event_end_date'){
        echo get_post_meta($post_id, "end_date", true);
    }
    if($column_name == 'event_time'){
        echo get_post_meta($post_id, "start_time", true).' - '.get_post_meta($post_id, "end_time", true);
    }
    if($column_name == 'project'){
        echo $project->get_project_name(get_post_meta($post_id, "project_id", true));
    }
}
add_filter( 'manage_calendar_posts_columns', 'calendar_custom_column' );
add_action( 'manage_calendar_posts_custom_column', 'calendar_custom_value', 10, 2 );
?>

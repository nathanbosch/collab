<?php
require_once("../../../wp-load.php");

session_start();

//Require full_path and current project id
if (!isset($_SESSION['current_project_id'])){
    wp_redirect( home_url() );
} 


include_once('file_browser_functions.php');
$fb = new file_browser;
$file = $fb->get_file_by_id($_GET['id']);

//Does file exist?
if(!$file) exit;

//Has curr user access to file?
if(!$fb->has_acces_to_id($_GET['id'])) exit;

//Get full path
$full_path = $fb->get_full_path();

//Generate full path
$path = $full_path.$file['path'];

//Replace invalid 
$invalids = array(  '../',
                    '>',
                    '<',
                    '|',
                    '?',
                    '*');


$path = str_replace($invalids,'',$path);

//Check if path exist
if(!file_exists($path)) exit;

header('Content-disposition: attachment; filename="'.$file['name'].'"');
readfile($path);
?>
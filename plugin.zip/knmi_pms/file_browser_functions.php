<?php
////////////////////////////////////////////////////////////////////
//
//    Project: KNMI PMS 
//    Author: Nathan Bosch  
//    
//    Function: This file contains all possible functions for a 
//    files and folders
//
////////////////////////////////////////////////////////////////////



class file_browser {
    
    private $base_dir;
    private $bin_dir;
    private $project_dir;
    private $current_dir;
    private $current_project_id;
    private $current_user_id;
    private $current_user_role;
    
    private $files = array();
    private $directories = array();
    private $is_file = false;
    
    private $invalids = array(  '../',
                                '>',
                                '<',
                                '\\',
                                '|',
                                '?',
                                '*',
                                ':',
                                ';');
    
    //Code should handle upper and lower case variations!
    private $valid_file_extensions = array(     //General formats
                                                'pdf', 
                                                'txt',
        
                                                //Zipped folders
                                                'zip',
                                                'zipx',
                                                '7z',
                                                's7z',
                                                'tar',
                                                'gz',
                                                'bz2',
        
                                                //Microsoft office
                                                'doc',
                                                'docx',
                                                'docm',
                                                'dotx',
                                                'dot',
                                                'xls',
                                                'xlt',
                                                'xlm',
                                                'ptt',
                                                'pot',
                                                'pps',
                                                'pptx',
                                                'pptm',
                                                'potx',
                                                'potm',
                                                'ppam',
                                                'ppsx',
                                           
                                                //Libe office
                                                'odt',
                                                'ott',
                                                'odm',
                                                'oth',
                                                'ods',
                                                'ots',
                                                'odg',
                                                'otg',
                                                'odp',
                                                'otp',
                                                'odf',
                                                'odb',
                                                'oxt',
                                           
                                                //Images
                                                'jpg',
                                                'jpeg',
                                                'png',
                                                'eps',
                                                'ps',
                                                'gif',
                                                'ai',
                                                'tif',
                                                'tiff',
        
                                                //Video files
                                                'avi',
                                                'wmv',
                                                'mp4',
                                                'mkv',
                                                'mov',

                                                //Data files
                                                'nc',
                                                'cdf',
                                                'gb',
                                                'grads',
                                                'grd',
                                                'ctl',

                                                //Scripts
                                                'py',
                                                'sc',
                                                'ksh',
                                                'sh',
                                                'jnl',
                                                'gs',
                                                'f',
                                                'f90'
    );
    
    private $roles_with_manager_access = array(   'manager');
    
    private $roles_with_user_access = array(    'manager',
                                                'member');
    
    private $forbidden_dir_names = array();
    
    private $project;
    private $ra;
    
    private $default_file_permissions = 0775;
    
    //Get base path
    function __construct($project_id = null) {
        if($project_id == null){
            $project_id = $_SESSION['current_project_id'];
        }
        
        $this->current_project_id = $project_id;
        
        //Construct base-directory
        $this->base_dir = ABSPATH;
        $this->base_dir .= 'knmi';
        $this->bin_dir = $this->base_dir.'_bin';
        
        //create base_dir
        if (! is_dir($this->base_dir)) {
            mkdir( $this->base_dir, $this->default_file_permissions );
            chmod($this->base_dir, $this->default_file_permissions );
        }
        if (! is_dir($this->bin_dir)) {
            mkdir( $this->bin_dir, $this->default_file_permissions );
            chmod($this->bin_dir, $this->default_file_permissions );
        }
        
        $this->project_dir = '/'.$this->get_folder_name();
        $this->project = new project;
        $this->ra = new recent_activities;
        $this->create_folder($project_id);
        $this->current_user_id = get_current_user_id();
        $this->current_user_role = $this->project->get_project_role();

	}
    
    public function show(){
        echo "<div id='file_browser'>";
        //Initialize
        $dir = sanitize_text_field($_GET['dir']);
        $new_dir = sanitize_text_field($_POST['new_dir']);
        $version = sanitize_text_field($_POST['version']);
        $new_dir_user_groups = $_POST['new_dir_user_groups'];
            
            
        
        $user_groups = $this->project->get_project_user_groups();
        $current_user_groups = $this->project->get_project_groups();
        
        //Set current dir
        $this->set_current_dir($dir);
        
        //Handle rev, del, and cga
        if(!$this->handle_user_input()) return;
            
        
        //Print file upload form
        if($this->has_user_access()){
            //Handle user interaction with jQuery
            echo '<script>$(document).ready(function(){$("span.fa-plus-circle").click(function(){$(this).parent().toggleClass("expand");});});</script>';
            
            echo"   <div id='file_upload'><span class='fa fa-plus-circle title'>Upload file(s)</span>
                        <form method='post' enctype='multipart/form-data'>
                            <label for='files'>Select file(s) to upload</label>
                            <input name='files[]' id='files' type='file' multiple='multiple'/>
                            <label for='version'>Enter the file version</label>
                            <input name='version' id='version' type='text'/>
                            <input name='submit' type='submit' value='Upload'/>
                        </form>
                    </div>
            ";

            //Handle uploads
            if(!empty($_FILES)){
                $this->upload_files($_FILES, $version);
            }
        }
        
        //Print new folder form
        if($this->has_user_access()){
            echo "<div id='new_folder'><span class='fa fa-plus-circle title'>Create new folder(s)</span>
                <form  method='post'>
                    <label for='new_dir'>Name for new folder</label>
                        <input name='new_dir' id='new_dir' type='text'/>
                ";
            
            if($this->has_manager_access()){
                echo "<label for='new_dir_user_groups[]'>Group access</label>";
                

                foreach($user_groups as $group){
                    $checked = '';
                    if(in_array($group, $current_user_groups) or $this->has_manager_access()) $checked = 'checked';
                    echo "<span class='group'><input type='checkbox' name='new_dir_user_groups[]' value='{$group}'  {$checked}/>{$group}</span>";
                }
            }
            echo "
                    <input name='submit' type='submit' value='Create folder(s)'/>
                </form>
                </div>
                ";
            
            //Handle new dir
            if(isset($new_dir)){
                $this->create_new_dir($new_dir, $new_dir_user_groups);
            }
        }
        
        //Default show browser
        $this->show_browser();
        
        echo "</div>";
    }
    
    private function handle_user_input(){
        
        $del = sanitize_text_field($_GET['del']);
        $cga = sanitize_text_field($_GET['cga']);
        $rev = sanitize_text_field($_GET['rev']);
        $version = sanitize_text_field($_POST['version']);
        $dir_new_user_groups = $_POST['dir_new_user_groups'];
        
        $user_groups = $this->project->get_project_user_groups();
        $current_user_groups = $this->project->get_project_groups();
        
        if(isset($rev) && $rev != ''){
            if(!$this->has_user_access()) return true;
            
            $file = $this->get_file_by_id($rev);
            $path =substr($this->get_file_by_id($rev)['path'],0,strrpos($this->get_file_by_id($rev)['path'],'/',-1));
            
            
            if(!empty($_FILES)){
                if(!$this->upload_revision($_FILES, $file['id'], $version)){
                echo '<meta http-equiv="refresh" content="0; url='.home_url().'/file_browser">';
                exit;
            }
            echo '<meta http-equiv="refresh" content="0; url='.home_url().'/file_browser'.$path.'">';
            exit;
            }

            else{
                echo "  <form id='revision' method='post' enctype='multipart/form-data'>
                            <label for='file'>Choose file for revision</label>
                            <input name='file' id='file' type='file'/>
                            <label for='version'>Enter the version</label>
                            <input name='version' id='version' type='text'/>
                            <input name='submit' type='submit' value='Upload'/>
                        </form>
                ";
                return false;
                
            }

        }
        
        //Handle delete
        if(isset($del) && $del != ''){
            if(!$this->has_user_access()) return true;
            
            //Go one dir back
            $path =substr($this->get_file_by_id($del)['path'],0,strrpos($this->get_file_by_id($del)['path'],'/',-1));
            if(!$this->remove_file_folder($del)){
                echo '<meta http-equiv="refresh" content="0; url='.home_url().'/file_browser">';
                exit;
            }
            echo '<meta http-equiv="refresh" content="0; url='.home_url().'/file_browser'.$path.'">';
            exit;
        }
        
        //New group assigment
        if(isset($cga) && $cga != ''){
            if(!$this->has_user_access()) return true;
            
            //Handle input
            if(isset($dir_new_user_groups) && $dir_new_user_groups != ''){
                $path = $this->get_file_by_id($cga)['path'];
                $path =substr($path,0,strrpos($path,'/',-1));
                
            
                
                if(!$this->assign_user_groups($cga,$dir_new_user_groups)){
                    echo '<meta http-equiv="refresh" content="0; url='.home_url().'/file_browser">';
                    exit;
                }
                echo '<meta http-equiv="refresh" content="0; url='.home_url().'/file_browser'.$path.'">';
                exit;
            }

            //Current assigned groups and the folder
            $assigned_user_groups = $this->get_folder_assigned_user_groups($cga);
            $folder = $this->get_file_by_id($cga);

            
            //Print
            echo "
                    <form id='group_access' method='post'>
                        <label class='title'>Groups with access to: {$folder['name']}</label>
            ";
            
            foreach($user_groups as $group){
                $checked = '';
                if(in_array($group, $assigned_user_groups)) $checked = 'checked';
                    echo "<span class='group'><input type='checkbox' name='dir_new_user_groups[]' value='{$group}' {$checked}/>{$group}</span>";
            }

            
            echo "      <input name='submit' type='submit' value='Assign'/>
                    </form>
            ";
            
            return false;
        }
        return true;
    }
    
    public function has_manager_access(){
        return in_array($this->current_user_role,$this->roles_with_manager_access);
    }
    
    public function has_user_access(){
        return in_array($this->current_user_role,$this->roles_with_user_access);
    }
    
    public function get_folder_assigned_user_groups($id){
        global $wpdb;
        $wpdb->show_errors();
        
        
        $sql = $wpdb->prepare( 
                                        "
                                        SELECT *
                                        FROM knmi_folder_access
                                        WHERE folder_id = %d
                                        ",
                                        array(
                                            $id
                                        )
                                    );
        
        $result = $wpdb->get_row($sql,ARRAY_A);
        
        $groups = unserialize($result['groups']);
        
        if(!is_array($groups)){
            $groups = array();
        }
        
        return $groups;
    }
    
    //Get full path to current dir
    //When $print = true => echo user friendly structure
    public function get_full_path($print = false){
        if($print){
            $crumbles = array('Home');
            $crumbles = array_filter(array_merge($crumbles, explode('/',$this->current_dir)));
            
            
            echo "<div id='path'>";
            
            $path = '/file_browser/';
            
            foreach($crumbles as $crumble){
                if($crumble != 'Home') $path .= $crumble.'/';
                echo "<a id='crumble'href='{$path}'>{$crumble}</a>";
            }
            
            echo "</div>";
        }
        else return $this->base_dir.$this->project_dir.$this->current_dir;
    }
    
    //Set current relative dirname
    public function set_current_dir($dir){
        //Replace invalid 
        $dir = str_replace($invalids,'',$dir);
        if($dir != ''){
            if(substr($dir, -1) == '/'){
                $dir = substr($dir, 0, -1);
            }
            if($dir[0] != '/'){
                $dir = '/'.$dir;
            }
        }
        
        if($dir != ''){
            if(!$this->has_access_to_dir($dir)){
                $this->current_dir = '';
                echo '<span class="error"><span class="message">You have no access to folder: '.$dir.'</span></span>';
                return;
            } 
        }
        
        $this->current_dir = $dir;
        
    }
    
    //Alias for has access to id
    public function has_access_to_dir($dir){
        return $this->has_acces_to_id($this->get_file_by_path($dir)['id']);
    }
    
    //Detect if current user has acces to folder or file (file based on folder)
    public function has_acces_to_id($id){
        //Compare project_id
        global $wpdb;
        $wpdb->show_errors();
        
        
        $sql = $wpdb->prepare( 
                                        "
                                        SELECT project_id
                                        FROM knmi_files
                                        WHERE id = %d
                                        ",  
                                            array(
                                                $id
                                            )
                                        );
        
        $result = $wpdb->get_row($sql,ARRAY_A);
       
        
        if(empty($result)) return false;
        if($result['project_id'] != $this->current_project_id) return;
        
        //Admin capabilities, let him pass
        if(in_array($this->current_user_role,$this->roles_with_manager_access)) return true;
        
        //If client let not view FILE revisions
        if($this->get_id_type($id) == 'file' && !$this->has_user_access() && !$this->is_greatest_revision($id)) return false;
        
        //Get current user_group
        $user_groups = $this->project->get_project_groups($this->current_user_id);
        
        //If file get id of folder
        if($this->get_id_type($id) == 'file'){
            $folder = $this->get_folder_of_file($id);
            if($folder == '') return true;
            $id = $folder['id'];
        }
        
        
        
        $sql = $wpdb->prepare( 
                                        "
                                        SELECT *
                                        FROM knmi_folder_access
                                        WHERE folder_id = %d
                                        ",  
                                            array(
                                                $id
                                            )
                                        );
        
        $result = $wpdb->get_row($sql,ARRAY_A);
        
        //No record, no access
        if(empty($result)) return false;
        else{
            //User groups with allowance
            $allowed_user_groups = unserialize($result['groups']);
            if(!is_array($allowed_user_groups)){
                $allowed_user_groups = array();
            }
            
            //If exist user has access, else not
            $matches = array_intersect($user_groups,$allowed_user_groups);
            if(count($matches) > 0) return true;
            else return false;
        }
    }
    
    //Create and print the actual file browser
    public function show_browser(){
        
        //Declare base and back location
        $curdir = $this->current_dir;
        $back = substr($curdir,0,strrpos($curdir,'/',-1));
        
        //Get files for current dir
        $this->get_files();
        
        
        
        
        //Print path breadcrumbs
        $this->get_full_path(true);
        
        
        //Print table
        echo "          <table id='files'>";
        
        //Print Header
        echo "          <tr>
                        <th></th>
                        <th>Filename</th>
                        <th>Created</th>
                        <th>Version</th>
                        <th>Groups assigned</th>
                        <th colspan='4'>Actions</th>
                        </tr>";
        //Loop directories
        foreach($this->directories as $directory){
            
            //Print accesible directory
            if($this->has_acces_to_id($directory['id'])){
                echo   "<tr>
                        <td class='small fa fa-folder-open'></td>
                        <td><a href='/file_browser{$directory['path']}'>{$directory['name']}</a></td>
                        <td class='time'>{$directory['time']}</td>
                        <td class='small'></td>
                        <td>{$directory['access_string']}</td>";
                
                //Change groups assignment is had manager access
                if(in_array($this->current_user_role,$this->roles_with_manager_access)) echo "<td class='small'><a href='/cga/{$directory['id']}' class='fa fa-users' title='Change assigned groups'></a></td>";
                else echo "<td></td>";
                
                //Print delete option if has user access
                if($this->has_user_access())  echo "<td class='small'></td><td class='small'><a class='fa fa-trash' onclick='confirm_deletion(event)' title='Delete this folder' href='/del/{$directory['id']}'</a></td>";
                else echo " <td></td><td></td>";
                
                //Direct link
                $link_url = home_url().'/file_browser'.$directory['path'];
                echo        "<td class='small'><p onclick='copy_link(\"{$link_url}\")' class='fa fa-link'></p></td>";
                
            }
            
            //Print unaccesible directory
            else{
                echo "  <tr>
                        <td class='small fa fa-folder'></td>
                        <td><span class='no_access'>(Access restricted) {$directory['name']}</span></td>
                        <td class='time'>{$directory['time']}</td>
                        <td class='small'></td>
                        <td>{$directory['access_string']}</td>
                        <td class='small'></td>
                        <td class='small'></td>
                        <td class='small'></td>
                        <td class='small'></td>";
            }
            
            //Close row
            echo "</tr>";
            
        }
        
        //Loop files
        foreach($this->files as $file){
            echo "      <tr>
                        <td class='small fa fa-file'></td>
                        <td><a href='/view/{$file['id']}'>{$file['name']}</a></td>
                        <td class='time'>{$file['time']}</td>
                        <td class='small'>{$file['version_string']}</td>
                        <td></td>
                        <td class='small'><a class='fa fa-download' title='Download this file' href='/download/{$file['id']}'></a></td>";
            
            //Print revision and delete button if has user access 
            if($this->has_user_access()) echo "<td class='small'><a class='fa fa-refresh' title='Upload revision' href='/rev/{$file['id']}'></a></td><td class='small'><a class='fa fa-trash' onclick='confirm_deletion(event)' title='Delete this file' href='/del/{$file['id']}'></a></td>";
            
            
            
            //Print some closeings
            else echo   "<td class='small'></td><td class='small'></td>";
            
            //Direct link
            $link_url = home_url().'/view/'.$file['id'];
            echo        "<td class='small'><p onclick='copy_link(\"{$link_url}\")' class='fa fa-link'></p></td>";
            
            echo        "</tr>";
            
            //Print the revisions if has user access
            if($file['base_file_id'] != 0 && $this->has_user_access()){
                foreach($this->get_file_revisions($file['base_file_id']) as $revision){
                echo "  <tr class='revision'>
                        <td class='small fa fa-file'></td>
                        <td><a href='/view/{$revision['id']}'>{$revision['name']}</a></td>
                        <td class='time'>{$revision['time']}</td>
                        <td class='small'>{$revision['version_string']}</td>
                        <td class='small'></td>
                        <td class='small'><a class='fa fa-download' title='Download this file' href='/download/{$file['id']}'></a></td>
                        <td class='small'></td>
                        <td class='small'><a class='fa fa-trash' onclick='confirm_deletion(event)' title='Delete this file' href='/del/{$revision['id']}'></a></td><td class='small'></td>
                        </tr>";
                }
            }
            
        }
        
        
        //Print closeing
        echo '</table>';
        
        //JS delete confirmation
        echo "<script>function confirm_deletion(e){ if (confirm('Are you sure about deleting this?')) { return; } else { e.preventDefault(); } }   function copy_link(text){window.prompt('Direct link', text);} </script>";
    
        
    }
    

    //Show all files in tree-form 
    //Used in backend for compact file selection
    //Hanlding of input done by calendar_functions.php and news_functions.php
    public function show_tree(){
        
        //Globliaze files to enable function looping
        global $files;
        $files = $this->get_all_files();
        $folders = $this->get_all_folders();
        
        
        //Sort array tree like 
        usort($folders, function($a, $b){
            //return strnatcmp($a['path'],$b['path']); //Case sensitive
            return strnatcasecmp($a['path'],$b['path']); //Case insensitive
        });
        
        //Handle user interaction with jQuery
        echo '<script>$(document).ready(function(){$("span.tree-folder > .fa").click(function(){$(this).parent().toggleClass("expand");$(this).toggleClass("fa-folder");$(this).toggleClass("fa-folder-open");});});</script>';
        
        //Keep track of files and foleders already printed
        global $array_printed;
        $array_printed = array();
    
        //Interate true all folders
        function loop_folders($folders){
            //Get arrays from base function
            global $array_printed;
            global $files;
            
            //Iterate folders
            foreach($folders as $key => $folder){
                
                //Skip if already printed
                if(in_array($folder['id'], $array_printed)) continue;

                //Print folders
                echo "<span class='full tree-folder'><span class='fa fa-folder'><span class='title'>".$folder['name']."</span></span>";

                //Mark as printed
                array_push($array_printed, $folder['id']);

                //Determine subfolders
                $the_folders = array();
                foreach($folders as $sub_folder){
                    if(substr($sub_folder['path'], 0, strlen($folder['path'])+1) === $folder['path'].'/'){
                        array_push($the_folders, $sub_folder);
                    }
                }
                
                //Print subfolders
                loop_folders($the_folders);
                
                //Print files of this folder
                foreach($files as $file_key => $file){
                    
                    //Determine folder path of file
                    $path = substr($file['path'],0,strrpos($file['path'],'/',-1));
                    
                    //If match then print
                    if($folder['path'] == $path){
                        echo "<span class='full'><input type='checkbox' name='add_files[]' value='{$file['id']}'/>{$file['name']} ({$file['version_string']})</span>";
                    }
                }
                
                //Close initial folder
                echo "</span>";
            }
        }
        
        //Execute folder looping
        loop_folders($folders);
		
		//Print files of root
		foreach($files as $file_key => $file){
			
			//Determine folder path of file
			$path = substr($file['path'],0,strrpos($file['path'],'/',-1));
			
			//If match then print
			if($path == ''){
				echo "<span class='full'><input type='checkbox' name='add_files[]' value='{$file['id']}'/>{$file['name']} ({$file['version_string']})</span>";
			}
		}
        
        return true;
    }
    
    //Get file array (path, name) by file id
    public function get_file_by_id($file_id){
        global $wpdb;
        $wpdb->show_errors();
        $sql = $wpdb->prepare( 
                                        "
                                        SELECT *
                                        FROM knmi_files
                                        WHERE id = %d
                                        AND project_id = %d
                                        ",
                                            array(
                                                $file_id,
                                                $this->current_project_id
                                            )
                                        );
        
        $result = $wpdb->get_row($sql,ARRAY_A);
        
        if(empty($result)) return false;
        else return $result;
    }
           
    //Get folder in which file exists
    public function get_folder_of_file($file_id){
        global $wpdb;
        $wpdb->show_errors();
        $sql = $wpdb->prepare( 
                                        "
                                        SELECT path
                                        FROM knmi_files
                                        WHERE id = %d
                                        AND project_id = %d
                                        ",
                                            array(
                                                $file_id,
                                                $this->current_project_id
                                            )
                                        );

        $result = $wpdb->get_row($sql,ARRAY_A);

        
        
        //No records, no folder
        if(empty($result)) return false;
        
        //Get the path
        $path = substr($result['path'],0,strrpos($result['path'],'/',-1));
        
        //Get array
        $folder = $this->get_file_by_path($path);
        
        if(empty($folder)) return false;
        return $folder;
        
    }
    
    //Get type of id (file, folder etc.)
    public function get_id_type($id){
        global $wpdb;
        $wpdb->show_errors();
        $sql = $wpdb->prepare( 
                                        "
                                        SELECT type
                                        FROM knmi_files
                                        WHERE id = %d
                                        AND project_id = %d
                                        ",
                                            array(
                                                $id,
                                                $this->current_project_id
                                            )
                                        );

        $result = $wpdb->get_row($sql,ARRAY_A);
        
        if(empty($result)) return false;
        else return $result['type'];
    }
    
    //Get file array (path, name, id) by path
    public function get_file_by_path($path){
        global $wpdb;
        $wpdb->show_errors();
        
        $sql = $wpdb->prepare( "
                                    SELECT id, path, name
                                    FROM knmi_files
                                    WHERE path = %s
                                    AND project_id = %d
                                ",  
                                    array(
                                        $path,
                                        $this->current_project_id
                                    )
                                );
        
        $result = $wpdb->get_row($sql,ARRAY_A);
        
        
        if(empty($result)) return false;
        else return $result;
    }
    
    //Unset revisions from input files
    public function remove_old_revisions($files){
        $base_file_ids = array();
        
        //Get all base_files
        foreach($files as $file){
            if($file['base_file_id'] != 0){
                array_push($base_file_ids,$file['base_file_id']);
            }
        }
        
        //Each base file_id schould be handles once
        $base_file_ids = array_unique($base_file_ids);
        
        
        //Remove base_files
        foreach($files as $key => $file){
            if(in_array($file['id'], $base_file_ids)) unset($files[$key]);
        }
        
        //Remove older revisions
        foreach($base_file_ids as $base_file_id){
            
            $greatest_version =  $this->get_greatest_revision($base_file_id);
            
            //Loop all files
            foreach($files as $key => $file){
                
                //Only handle the files with appropiate base_file
                if($file['base_file_id'] == $base_file_id && $file['version'] != $greatest_version){
                    unset($files[$key]);
                
                }
            }
            
        }
        
        //Return new file set
        return $files;
    }
    
    //get revision by base file_id
    public function get_file_revisions($base_file_id){
        global $wpdb;
        $wpdb->show_errors();
        $sql = $wpdb->prepare( 
                                            "
                                            SELECT *
                                            FROM knmi_files
                                            WHERE project_id = %d
                                            AND type = 'file'
                                            AND (id = %d
                                            OR base_file_id = %d)
                                            ORDER BY version DESC
                                            ",
                                                array(
                                                    $this->current_project_id,
                                                    $base_file_id,
                                                    $base_file_id
                                                )
                                            );
        
        $results = $wpdb->get_results($sql,ARRAY_A);
        
        //Just revisions exclude the newset
        unset($results[0]);
        
        return $results;
    }
    
    //List files and directories in path
    public function get_all_files(){ 
        global $wpdb;
        $wpdb->show_errors();
        
        $sql = $wpdb->prepare( 
                                        "
                                        SELECT id, name, path, type, version, version_string, base_file_id
                                        FROM knmi_files
                                        WHERE project_id = %d
                                        AND type = 'file'
                                        ORDER BY name ASC
                                        ",
                                            array(
                                                $this->current_project_id
                                            )
                                        );
        
        $results = $wpdb->get_results($sql,ARRAY_A);
        
        $results = remove_timestamp($results);
        
        
        
        return $results;
    }
    
    //List files and directories in path
    public function get_all_folders(){ 
        global $wpdb;
        $wpdb->show_errors();
        
        $sql = $wpdb->prepare( 
                                        "
                                        SELECT id, name, path, type, version, version_string, base_file_id
                                        FROM knmi_files
                                        WHERE project_id = %d
                                        AND type = 'folder'
                                        ORDER BY name ASC
                                        ",
                                            array(
                                                $this->current_project_id
                                            )
                                        );
        
        $results = $wpdb->get_results($sql,ARRAY_A);
        
        $results = remove_timestamp($results);
        $results = add_folder_level($results);
        
        
        
        return $results;
    }
    
    //List files and directories in path
    public function get_all_files_info($files = null){ 
        global $wpdb;
        $wpdb->show_errors();
        
        if($files == null){
            return $files;
        }
        
        elseif(is_array($files)){
            $files = implode(",",$files);
         
            $sql = $wpdb->prepare( 
                                            "
                                            SELECT id, name, time, path, type, version, version_string, base_file_id
                                            FROM knmi_files
                                            WHERE project_id = %d
                                            AND type = 'file'
                                            AND id IN({$files})
                                            ",
                                                array(
                                                    $this->current_project_id
                                                )
                                            );
            
            
            $results = $wpdb->get_results($sql,ARRAY_A);
        }
        
     
        
        $results = remove_timestamp($results);
        
        //Access
        foreach($results as $key => $result){
            $results[$key]['access'] = $this->has_acces_to_id($result['id']);
        }
        
        
        return $results;
    }
    
    //List files and directories in path
    private function get_files(){
        
        $path = $this->current_dir;
        
        $path_level = substr_count($path,'/');
        
        global $wpdb;
        $wpdb->show_errors();
        $sql = $wpdb->prepare( 
                                        "
                                        SELECT *
                                        FROM knmi_files as t1 LEFT JOIN knmi_folder_access as t2 ON t1.id = t2.folder_id
                                        WHERE t1.project_id = %d
                                        AND t1.path LIKE %s
                                        AND t1.path != %s
                                        AND t1.type IN('file','folder')
                                        ORDER BY t1.name
                                        ",
                                            array(
                                                $this->current_project_id,
                                                $path.'/%',
                                                $path
                                            )
                                        );
        
        
        $results = $wpdb->get_results($sql,ARRAY_A);
        
        
        $files = array();
        $directories = array();
        
        //Distinguish files and directories
        foreach($results as $result){
            if(!$this->path_exist($result['path'])) continue;
            
            if(substr_count($result['path'],'/') > $path_level+1) continue;
            
            $groups = unserialize($result['groups']);
            if(!is_array($groups)){
                $groups = array();
            }
            
            //Do directories
            if($result['type'] == 'folder'){
                $result['access_string'] = implode(', ',array_map("ucfirst",$groups));
                array_push($directories, $result);
            }
                
            //Do files
            elseif($result['type'] == 'file'){
                array_push($files, $result);
            }
        }
        
        $files = $this->remove_old_revisions($files);
        
        //Store them
        $this->files = $files;
        $this->directories = $directories;
    }
    
    //Check if path exist in filebase
    public function path_exist($path){
        $path = $this->base_dir.$this->project_dir.$path;
        return file_exists($path);
    }
    
    //Check if path exist in databse
    public function path_exist_db($path){
        global $wpdb;
        $wpdb->show_errors();
        $sql = $wpdb->prepare( 
                                        "
                                        SELECT name
                                        FROM knmi_files
                                        WHERE path = %s
										AND project_id = %d
                                        ",
                                            array(
                                                $path,
												$this->current_project_id
                                            )
                                        );
        
        $result = $wpdb->get_row($sql,ARRAY_A);

        
        if(empty($result)) return false;
        else return true;
    }
    
    //Create new folder for project
    public function create_folder($project_id){

        //If folder already exist
        if($this->get_folder_name($project_id)){
            return false;
        }

        //Create folder name
        $folder_name = strtolower($this->project->get_project_name($project_id)).'_'.time();
        $new_dir = $this->base_dir.'/'.$folder_name;

        //create folder
        if (! is_dir($new_dir)) {
            mkdir( $new_dir, $this->default_file_permissions );
            chmod($new_dir, $this->default_file_permissions );
        }

        //Set to databse
        global $wpdb;
        $wpdb->show_errors();
        $query = $wpdb->prepare( 
                                "
                                    INSERT INTO knmi_files
                                    ( project_id, name, path, type)
                                    VALUES ( %d, %s, %s, %s )
                                ",  
                                    array(
                                        $project_id, 
                                        $folder_name,
                                        '/'.$folder_name,
                                        'base_folder'
                                    ) 
                                );

        //Do query
        $wpdb->query($query);
    }

    //Get name of folder for project
    public function get_folder_name($project_id = null){
        if($project_id == null) $project_id = $this->current_project_id;
        
        global $wpdb;
        $wpdb->show_errors();
        $sql = $wpdb->prepare( 
                                        "
                                        SELECT name
                                        FROM knmi_files
                                        WHERE project_id = %d
                                        AND type = 'base_folder'
                                        ",
                                            array(
                                                $project_id
                                            )
                                        );
        
        $result = $wpdb->get_row($sql,ARRAY_A);

        
    
        return $result['name'];
    }
    
    public function get_base_file($file_id){
        
        return $this->get_file_by_id($this->get_base_file_id($file_id));
        
    }
    
    public function get_base_file_id($file_id){
        
        if($file_id == null) return false;
        
        global $wpdb;
        $wpdb->show_errors();
        
        $base_file_id = $file_id;
        
        $sql = $wpdb->prepare( 
                                        "
                                        SELECT base_file_id, id
                                        FROM knmi_files
                                        WHERE project_id = %d
                                        AND id = %d
                                        ",
                                            array(
                                                $this->current_project_id,
                                                $file_id
                                            )
                                        );
        
        $result = $wpdb->get_row($sql,ARRAY_A);


        $base_file_id = $result['base_file_id'];
    
        if($base_file_id == 0) return $file_id;
        
       
        return $base_file_id;
        
    }
    
    public function get_greatest_revision($file_id){
        
        if($file_id == null) return false;
        
        $base_file_id = $this->get_base_file_id($file_id);
        
        global $wpdb;
        $wpdb->show_errors();
        
        $sql = $wpdb->prepare( 
                                        "
                                        SELECT max(version) as version
                                        FROM knmi_files
                                        WHERE project_id = %d
                                        AND base_file_id = %d
                                        ",
                                            array(
                                                $this->current_project_id,
                                                $base_file_id
                                            )

        );
        
        $result = $wpdb->get_row($sql,ARRAY_A);

        
        $version = 1;
        
        if($result['version'] != 0){
            $version = $result['version'];
        } 
        
        return $version;
        
    }
    
    public function is_greatest_revision($file_id){
        
        if($file_id == null) return false;
        $base_file_id = $this->get_base_file_id($file_id);
        
        if($base_file_id == 0) return true;
        
        
        global $wpdb;
        $wpdb->show_errors();
        
        $sql = $wpdb->prepare( 
                                        "
                                        SELECT max(version) as version, MAX(id) as id
                                        FROM knmi_files
                                        WHERE project_id = %d
                                        AND (base_file_id = %d
                                        OR id = %d)
                                        ",
                                            array(
                                                $this->current_project_id,
                                                $base_file_id,
                                                $base_file_id
                                            )

        );
        
        $result = $wpdb->get_row($sql,ARRAY_A);
        
        if($result['id'] == $file_id) return true;
        else return false;
        
    }
    
    //Upload file
    public function upload_files($files, $version_string = null){
        //User capabilities, let him pass
        if(!in_array($this->current_user_role,$this->roles_with_user_access))  return false;
       
 
        //Get base path
        $path = $this->get_full_path();
        
        //Loop all uploads
        for($i=0; $i<count($files['files']['name']); $i++) {
            
            //Default values
            $version = 1;
            $base_file_id = 0;
            $file = $files['files']['name'][$i];
            $file_name = $files['files']['name'][$i];
            
            
            //check extension validity
            if(!in_array(pathinfo($files['files']['name'][$i], PATHINFO_EXTENSION), $this->valid_file_extensions)){
                echo '<span class="error"><span class="message">Extension is not allowed</span></span>';
                return false;
            }
            
            //Skip empty filenames
            if(empty($file)) continue;
            
            
            //Uniqify name
            $file = time().'_'.$file;
            
            //New file location
            $loc = $path.'/'.$file;
            
            //Move file
            move_uploaded_file($files['files']['tmp_name'][$i], $loc);
        


 
            //Save in database
            global $wpdb;
            $wpdb->show_errors();
            $query = $wpdb->prepare( 
                                "
                                    INSERT INTO knmi_files
                                    ( project_id, name, path, type, version, version_string, base_file_id)
                                    VALUES ( %d, %s, %s, %s, %d, %s, %d )
                                ",  
                                    array(
                                        $this->current_project_id, 
                                        $file_name,
                                        $this->current_dir.'/'.$file,
                                        'file',
                                        $version,
                                        $version_string,
                                        $base_file_id
                                    ) 
                                );

            //Do query
            $wpdb->query($query);
            
            //Log
            $item_id = $this->get_file_by_path($this->current_dir.'/'.$file)['id'];
            
            //Log
            $this->ra->log_activity('Uploaded new file: '.$file_name, $item_id);
        
	
     }
        
        
    }
    
    //Upload file
    public function upload_revision($file, $old_file, $version_string = null){
        
        //User capabilities, let him pass
        if(!in_array($this->current_user_role,$this->roles_with_user_access)){
            return false;
        }
        
        //Has access to id
        if(!$this->has_acces_to_id($old_file)){
            return false;
        }
       
        //Skip empty filenames
        if(empty($file) or empty($old_file) or empty($file['file']['name'])){
            return false;
        }
        
        //check extension validity
        if(!in_array(pathinfo($file['file']['name'], PATHINFO_EXTENSION), $this->valid_file_extensions)){
            echo 'Extension is not allowed';
            return false;
        }
        
        // The OLD file   
        $base_file_id = $this->get_base_file_id($old_file);
        $old_file = $this->get_file_by_id($old_file);
        
        //Skip empty filenames
        if($base_file_id == 0 or empty($old_file)){
            return false;
        }
        
        
        //Default values for new file
        $version = $this->get_greatest_revision($old_file['id'])+1;
        
        //Get real dir old file
        $length = strlen($old_file['name']) + 12;
        $old_file_dir = substr($old_file['path'], 0, 0 - ($length));

        //New file name
        $file_name = $file['file']['name'];
        $file_name_db = time().'_'.$file_name;

        //New file location
        $loc = $this->base_dir.$this->project_dir.$old_file_dir.'/'.$file_name_db;

        //Move file
        move_uploaded_file($file['file']['tmp_name'], $loc);
        
     
        //Save in database
        global $wpdb;
        $wpdb->show_errors();
        $query = $wpdb->prepare( 
                            "
                                INSERT INTO knmi_files
                                ( project_id, name, path, type, version, version_string, base_file_id)
                                VALUES ( %d, %s, %s, %s, %d, %s, %d )
                            ",  
                                array(
                                    $this->current_project_id, 
                                    $file_name,
                                    $old_file_dir.'/'.$file_name_db,
                                    'file',
                                    $version,
                                    $version_string,
                                    $base_file_id
                                ) 
                            );

        //Do query
        $wpdb->query($query);

        //Log
        $item_id = $this->get_file_by_path($old_file_dir.'/'.$file_name_db)['id'];

        //Log
        $this->ra->log_activity('Uploaded revision: '.$file_name, $item_id);
        
        //redirect (best way possible)
        return true;
}
    
    //Upload file
    public function create_new_dir($dirnames, $user_groups){
        //User capabilities, let him pass
        if(!in_array($this->current_user_role,$this->roles_with_user_access)) return false;
        
        if(!is_array($user_groups)){
            $user_groups = array();
        }
        
        //Remove invalid user_groups
        if(in_array($this->current_user_role,$this->roles_with_manager_access)){
            $existing_user_groups = $this->project->get_project_user_groups();
            $user_groups = array_intersect($existing_user_groups, $user_groups);
        }
        else{
            if(!in_array('none',$this->project->get_project_groups())){
                $user_groups = $this->project->get_project_groups();
            }
            else{
                $user_groups = array();
            }
        }
        
        //Split on ; for multiple dir creations at once.
        $dirnames = explode(';',$dirnames);
        
        //Loop all dirs
        foreach($dirnames as $dirname){
            //filter dir name
            $dirname = str_replace($invalids, '', $dirname);
            $dirname = str_replace(' ', '_', $dirname);
            
            //Skip empty onces
            if(empty($dirname)) continue;
            
            //Forbidden names
            if(in_array($dirname, $this->forbidden_dir_names)) continue;
            
            //Generate path for new dir
            $path = $this->get_full_path().'/'.$dirname;
            
            //If path eixist in db or filebase then skip
            if($this->path_exist($this->current_dir.'/'.$dirname) || $this->path_exist_db($this->current_dir.'/'.$dirname)) continue;

            //create folder
            if (! is_dir($path)) {
                mkdir( $path, $this->default_file_permissions );
                chmod($path, $this->default_file_permissions );
            }
            
            //Save in database
            global $wpdb;
            $wpdb->show_errors();
            $query = $wpdb->prepare( 
                                "
                                    INSERT INTO knmi_files
                                    ( project_id, name, path, type)
                                    VALUES ( %d, %s, %s, %s )
                                ",  
                                    array(
                                        $this->current_project_id, 
                                        $dirname,
                                        $this->current_dir.'/'.$dirname,
                                        'folder'
                                    ) 
                                );

            //Do query
            $wpdb->query($query);
            
            
            $item_id = $this->get_file_by_path($this->current_dir.'/'.$dirname)['id'];
            
            $this->assign_user_groups($item_id, $user_groups, true);
            
            
            //Log
            $this->ra->log_activity('Created new folder: '.$dirname, $item_id);
        }
    }
    
    public function assign_user_groups($id, $groups, $force = false){
        //User capabilities, let him pass
        if(!in_array($this->current_user_role,$this->roles_with_user_access)){
            return false;
        }
        
        if(!$this->has_acces_to_id($id) && !$force) return false;
        global $wpdb;
        $wpdb->show_errors();
        //Access rights
        $query = $wpdb->prepare( 
                            "
                                INSERT INTO knmi_folder_access
                                (folder_id, groups)
                                VALUES (%d, %s)
                                ON DUPLICATE KEY UPDATE groups = %s
                            ",  
                                array(
                                    $id,
                                    serialize($groups),
                                    serialize($groups)
                                ) 
                            );
        $wpdb->query($query);
        
        return true;
    }
    
    //Remove file or folder
    public function remove_file_folder($id){
        //User capabilities, let him pass
        if(!in_array($this->current_user_role,$this->roles_with_user_access)){
            return false;
        }
        
        //Has access to id
        if(!$this->has_acces_to_id($id)){
            return false;
        }
        
        //Save in database
        global $wpdb;
        $wpdb->show_errors();
        
        //Get path
        $sql = $wpdb->prepare( 
                                    "
                                    SELECT path, name, type
                                    FROM knmi_files
                                    WHERE project_id = %d
                                    AND id = %d
                                    AND type IN('file','folder')
                                    ",
                                        array(
                                            $this->current_project_id,
                                            $id
                                        )

        );
        
        
        $result = $wpdb->get_row($sql,ARRAY_A);

        
        if(empty($result)){
            return false;
        }
        
        
        
        if($result['type'] == 'file'){
            //Get actual filename
            $length = strlen($result['name']) + 11;
            $old_path = $this->base_dir.$this->project_dir.$result['path'];
            $new_path = $this->bin_dir.'/'.time().'_'.substr($result['path'], 0 - ($length));
            $old_file_dir = substr($result['path'], 0, 0 - ($length));

            //Move to bin folder
            copy($old_path, $new_path);
            unlink($old_path);

            //Remove from db
            $query = $wpdb->prepare( 
                                "
                                    DELETE FROM knmi_files
                                    WHERE project_id = %d
                                    AND id = %d
                                ",  
                                    array(
                                        $this->current_project_id, 
                                        $id
                                    ) 
                                );

            //Do query
            $wpdb->query($query);
            
            $this->ra->log_activity('Removed file: '.$result['name'], $id);
        
        }
        
        elseif($result['type'] == 'folder'){
            $old_path = $this->base_dir.$this->project_dir.$result['path'];
            $new_path = $this->bin_dir.$result['path'].'_'.time();
            $length = strlen($result['name']) + 1;
            $old_file_dir = substr($result['path'], 0, 0 - ($length));
            $this->copy_folder($old_path, $new_path);
            $this->remove_folder($old_path);
            //Remove from db
            $query = $wpdb->prepare( 
                                "
                                    DELETE FROM knmi_files
                                    WHERE project_id = %d
                                    AND path LIKE '%s'
                                    OR id = '%d'
                                ",  
                                    array(
                                        $this->current_project_id,
                                        $result['path'].'/%',
                                        $id
                                    )
                                );

            //Do query
            $wpdb->query($query);
            
            //Remove from db
            $query = $wpdb->prepare( 
                                "
                                    DELETE FROM knmi_folder_access
                                    WHERE folder_id = '%d'
                                ",  
                                    array(
                                        $id
                                    ) 
                                );

            //Do query
            $wpdb->query($query);
            
            $this->ra->log_activity('Removed folder: '.$result['name'], $id);
        
        }
        
        
        //Log
        //redirect (best way possible)
        return true;
        
        
    }
    
    //THANX TO PHP.NET 
    //Copy folder recrusively to new directory
    function copy_folder($src,$dst) { 
        $dir = opendir($src); 
        @mkdir($dst, $this->default_file_permissions, true); 
        @chmod($dst, $this->default_file_permissions );
        while(false !== ( $file = readdir($dir)) ) { 
            if (( $file != '.' ) && ( $file != '..' )) { 
                if ( is_dir($src . '/' . $file) ) { 
                    $this->copy_folder($src . '/' . $file,$dst . '/' . $file); 
                } 
                else { 
                    copy($src . '/' . $file,$dst . '/' . $file); 
                } 
            } 
        } 
        closedir($dir); 
    } 
    
    //THANX TO PHP.NET example
    //Remove folder recrusively 
    function remove_folder($path){
        $dir = opendir($path); 
        while(false !== ( $file = readdir($dir)) ) { 
            if (( $file != '.' ) && ( $file != '..' )) { 
                if ( is_dir($path . '/' . $file) ) { 
                    $this->remove_folder($path.'/'.$file); 
                } 
                else { 
                    unlink($path . '/' . $file); 
                } 
            } 
        } 
        closedir($dir);
        rmdir($path);
    }

}

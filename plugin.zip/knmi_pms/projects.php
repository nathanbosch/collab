<?php
////////////////////////////////////////////////////////////////////
//
//    Project: KNMI PMS 
//    Author: Nathan Bosch  
//    
//    Function: This files handles the PROJECTS custom post type, 
//    including the saving and retrieving of the custom metafield 
//    like user roles and groups.
//
////////////////////////////////////////////////////////////////////

//Build taxonomy/categories
function project_taxonomies() {
    register_taxonomy( 'project_category', 'projects', array( 'hierarchical' => true, 'label' => 'Category', 'rewrite' => true ) );
}
add_action( 'init', 'project_taxonomies', 0 );

//Build projects post type
function project_post_type() {
	$labels = array(
	  'name' => _x('Projects', 'Cpost type general name'),
	  'singular_name' => _x('Project', 'Cpost type singular name'),
	  'add_new' => _x('Add new', 'Project'),
	  'add_new_item' => __('Add new project'),
	  'edit_item' => __('Edit project'),
	  'new_item' => __('New project'),
	  'view_item' => __('View project'),
	  'search_items' => __('Find project'),
	  'not_found' =>  __('No projects found'),
	  'not_found_in_trash' => __('No projects found in bin')
	);
	$args = array(
	  'labels' => $labels,
	  'public' => true,
	  'publicly_queryable' => true,
	  'show_ui' => true,
	  'exclude_from_search' => false,
	  'query_var' => true,
	  'rewrite' => array( 'slug' => 'project' ),
        'capabilities' => array(
            'edit_post' => 'edit_project',
            'edit_posts' => 'edit_projects',
            'edit_others_posts' => 'edit_other_projects',
            'publish_posts' => 'publish_projects',
            'read_post' => 'read_project',
            'read_private_posts' => 'read_private_projects',
            'delete_post' => 'delete_project'
        ),
	  'hierarchical' => false,
	  'menu_position' => 20,
      'menu_icon' => 'dashicons-portfolio',
      'supports' => array('title','editor','thumbnail'),
   	  'taxonomies' => array( 'project_category' ),
      'register_meta_box_cb' => 'project_add_custom_metaboxes'
	);
	register_post_type('projects',$args);
	
	
}
add_action( 'init', 'project_post_type' );


//Build metaboxes 
function project_add_custom_metaboxes() {
    add_meta_box('project_metabox_users', 'Project users', 'project_users_html', 'projects', 'normal', 'core');
    add_meta_box('project_metabox_modules', 'Project modules', 'project_modules_html', 'projects', 'normal', 'core');
    add_meta_box('project_metabox_groups', 'Project groups', 'project_groups_html', 'projects', 'normal', 'core');

}

//Provide eta box HTML
function project_users_html() {
    // Noncename needed to verify where the data originated
	echo '<input type="hidden" name="meta_noncename" id="meta_noncename" value="' . 
	wp_create_nonce( plugin_basename(__FILE__) ) . '" />';
    
    //Get current post
	global $post;
    $project_id = $post->ID;
    
    global $pagenow;
    
    //Get project class
    $project = new project;
    
    //Get users and groups
    $users = get_users(array('orderby' => 'login'));
    $groups = $project->get_project_user_groups($project_id);
    
    //Echo headers
    ?>
    <ul id="header" class="third">
        <li>User</li>
        <li>Project role<p class="description">Assign a role for the user (Select none, for no project access)</p></li>
        <li>Project groups (Hover to expand)<p class="description">When checked, the user is assigned to the group</p></li>
    </ul>
    <?php
    
    foreach($users as $user){
        //Administrator has access to all do not list
        if(in_array('administrator', $user->roles)) continue;
        
        $user_id = $user->ID;
        
        $roles = $project->get_roles();
        $user_role = $project->get_project_role($project_id, $user_id);
        
        //Get current group
        $project_groups = $project->get_project_groups($user_id, $project_id);
        
        //Echo forms
        echo '<ul id="row" class="third">';
        echo '<li>'.$project->get_user_formal_name($user_id).' ('.$user->user_login.')</li>';
        echo '<li><select id="'.$user_id.'_project_role" name="'.$user_id.'_project_role">';
            
            echo '<option value="none">None</option>';
        
        foreach($roles as $key => $role){
            $selected = '';
            if(in_array( $pagenow, array( 'post-new.php' ) ) && $user_id == get_current_user_id()){
                $selected = 'selected';
            }
            
            if($key == $user_role) $selected = 'selected';
            echo '<option value="'.$key.'" '.$selected.'>'.$role.'</option>';
        }
        
        echo '</select></li>';
        
        
        echo '<li class="shrink">';
        //Loop all groups
        foreach($groups as $group){
            if(in_array($group,$project_groups)){
                $checked="checked";
            }
            else{
                $checked = '';
            }
            echo '<span class="block"><input id="'.$user_id.'_project_groups[]" name="'.$user_id.'_project_groups[]" value="'.$group.'" '.$checked.' type="checkbox"/>'.$project->get_project_nice_name($group).'</span>';
        }
        
        echo '</li>';
    }
}

//Provide metabox module hmtl
function project_modules_html() {
    
    //Get current project
	global $post;
    $project_id = $post->ID;
    
    //Project class
    $project = new project;
    
    global $pagenow;
    
    //Get & sort (active) modules
	$modules = $project->get_all_modules();
    asort($modules);
    $active_modules = $project->get_project_modules($project_id);
    $login_rules = $project->module_login_required($project_id);
    
    if(!is_array($active_modules)){
        $active_modules = array();
    }
    
    //Echo forms
    echo '<ul id="row" class="half">';
    echo '<li class="header">Modules<p class="description">Check the modules you wish to enable for the project.</p></li><li class="header">Require login<p class="description">When UNchecked, the module will be accesible without login.</p></li>';
    
   
    //Loop modules and preselect the active
    foreach($modules as $module_id => $module_name){   
        
        $checked = '';
        
        if(in_array($module_id,$active_modules) or in_array( $pagenow, array( 'post-new.php' ) )){
            $checked = 'checked';
        }

        //Echo forms
        echo '<li><input type="checkbox" name="modules[]" value="'.$module_id.'" '.$checked.'/>'.$module_name.'</li>';
    
    
        $checked = '';
        
        if($login_rules[$module_id] == 'true' or in_array( $pagenow, array( 'post-new.php' ) )){
            $checked = 'checked';
        }
    
        //Login rule
        echo '<input type="checkbox" name="login_rules[]" value="'.$module_id.'" '.$checked.'/>';
    }
    
    
    echo '</ul>';

}

//Provide metabox groups hmtl
function project_groups_html() {
    
    //Get current project
	global $post;
    $project_id = $post->ID;
    
    //Project class
    $project = new project;
    
    //Get current groups
	$groups = $project->get_project_user_groups($project_id);
    
    if(!is_array($groups)){
        $groups = array();
    }
    
    
    //Echo forms
    echo '<ul id="row" class="half">';
    echo '<li>';
    echo '<p class="description">To delete a group: Check it and press the UPDATE button</p>';
    
    foreach($groups as $group){
        echo '<span class="full"><input type="checkbox" name="delete_groups[]" value="'.$group.'"/>'.$project->get_project_nice_name($group).'</span>';
    }
    
    echo '</li>';
    echo '<li>';
    
    echo '<p class="description">Add new groups (separate with ; for multiple) and press the UPDATE button</p>';
    echo '<input type="text" name="new_group" id="new_group" placeholder="Name of new group"/>';
    
    echo '</li>';
    echo '<input class="center button button-primary button-large" type="submit" value="Update"/>';
    echo '</ul>';
}


//Meta box save-ing
function project_save_custom_meta($post_id, $post) {
    
    //Get current project
    $project_id = $post->ID;
    
    //project class
    $project = new project;
    
    //Verify Nonce
    if ( !wp_verify_nonce( $_POST['meta_noncename'], plugin_basename(__FILE__) )) {
	   return $post->ID;
	}

	//Verify permissions
	if ( !current_user_can( 'edit_post', $post->ID ))
		return $post->ID;
    
    //Save new groups
    if(isset($_POST['new_group']) && !empty($_POST['new_group'])){
        $groups = explode(';', $_POST['new_group']);
        $project->update_project_user_groups($project_id, $groups);
    }
    
    //Delete groups
    if(isset($_POST['delete_groups']) && !empty($_POST['delete_groups'])){
        $delete_groups = $_POST['delete_groups'];
        $project->delete_project_user_groups($project_id, $delete_groups);
    }

    //Loop users
    $all_users = get_users(array('orderby' => 'login'));
    foreach ($all_users as $user) {
        $user_id = $user->ID;
        
        //Save user role
        if(isset($_POST[$user_id.'_project_role']) && !empty($_POST[$user_id.'_project_role'])){
            $project->set_project_role($_POST[$user_id.'_project_role'], $project_id, $user_id );
        }
        
        //Save user group
        if(isset($_POST[$user_id.'_project_groups']) && !empty($_POST[$user_id.'_project_groups'])){
            $project->update_project_groups($user_id, $project_id, $_POST[$user_id.'_project_groups']);
        }
    }
    
    //Login rules
    $login_rules = $_POST['login_rules'];
    $project->set_module_login_required_rules($project_id,$login_rules);
    
    //Save modules
    $modules = $_POST['modules'];
    $project->update_project_modules($project_id,$modules);
    
}
add_action('save_post', 'project_save_custom_meta', 1, 2); // save the custom fields

//Custom table
function projects_custom_column($cols) {
    
    $project = new project;
    print_r($project->get_roles());
    
    //Add custom columns before the date column
    $new = array();
    
    foreach($cols as $key => $title) {
        if ($key=='date'){
            foreach($project->get_roles() as $key_2 => $role){
                
                $new[$key_2] = __($role).'(s)';
            }
            $new['groups'] = __('Group(s)');
        }
        $new[$key] = $title;
    }
    return $new;
}

function projects_custom_value($column_name, $post_id) {
    
    $project = new project;
    
    foreach($project->get_roles() as $key => $role){

        if($column_name == $key){
        
            foreach($project->get_users_with_project_role($key, $post_id) as $user){
                echo $project->get_user_formal_name( $user ).'<br/>';
            }
        }
        
    }
            
    if($column_name == 'groups'){
        foreach($project->get_project_user_groups($post_id) as $project_group){
            echo $project->get_project_nice_name($project_group).'<br/>';
        }
    }
}
add_filter( 'manage_projects_posts_columns', 'projects_custom_column' );
add_action( 'manage_projects_posts_custom_column', 'projects_custom_value', 10, 2 );

//When new project is created add and attach forum
add_action( 'transition_post_status', 'a_new_post', 10, 3 );

function a_new_post( $new_status, $old_status, $post )
{
    
    if ( 'publish' !== $new_status or 'publish' === $old_status )
        return;
    
    if ( 'projects' !== $post->post_type )
        return;
    

    
    
    //Attach forum
    $project = new project;
    $project->create_forum($post);
}
?>

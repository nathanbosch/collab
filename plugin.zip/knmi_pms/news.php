<?php
////////////////////////////////////////////////////////////////////
//
//    Project: KNMI PMS 
//    Author: Nathan Bosch  
//    
//    Function: This files handles the NEWS custom post type, 
//    including the saving and retrieving of the custom metafields
//
////////////////////////////////////////////////////////////////////


//Build news post type
function news_post_type() {
	$labels = array(
	  'name' => _x('News', 'Cpost type general name'),
	  'singular_name' => _x('Newsarticle', 'Cpost type singular name'),
	  'add_new' => _x('Add new', 'Article'),
	  'add_new_item' => __('Add new article'),
	  'edit_item' => __('Edit article'),
	  'new_item' => __('New article'),
	  'view_item' => __('View article'),
	  'search_items' => __('Find article'),
	  'not_found' =>  __('No articles found'),
	  'not_found_in_trash' => __('No articles found in bin')
	);
	$args = array(
	  'labels' => $labels,
	  'public' => true,
	  'publicly_queryable' => true,
	  'show_ui' => true,
	  'exclude_from_search' => false,
	  'query_var' => true,
	  'rewrite' => array( 'slug' => 'news' ),
        'capabilities' => array(
            'edit_post' => 'edit_article',
            'edit_posts' => 'edit_articles',
            'edit_others_posts' => 'edit_other_articles',
            'publish_posts' => 'publish_articles',
            'read_post' => 'read_article',
            'read_private_posts' => 'read_private_articles',
            'delete_post' => 'delete_article'
        ),
	  'hierarchical' => false,
	  'menu_position' => 20,
      'menu_icon' => 'dashicons-format-aside',
	  'supports' => array('title','editor','thumbnail'),
      'register_meta_box_cb' => 'news_add_custom_metaboxes'
	);
	register_post_type('news',$args);
	
	
}
add_action( 'init', 'news_post_type' );

//Metaboxes of post type
function news_add_custom_metaboxes() {
    add_meta_box('news_metaboxes', 'Attached files', 'news_custom_metabox_html_files', 'news', 'normal', 'core');
}

//Meta box HTML
function news_custom_metabox_html_files() {
    global $post;
    
    // Noncename needed to verify where the data originated
	echo '<input type="hidden" name="meta_noncename" id="meta_noncename" value="' . 
	wp_create_nonce( plugin_basename(__FILE__) ) . '" />';
    
   global $post;
    
    $fb = new file_browser();
    $calendar = new calendar();
    
    $attached_files = $fb->get_all_files_info($calendar->get_attached_files($post->ID));
    $all_files = $fb->get_all_files();
    
    //Echo forms
    echo '<ul id="row" class="half">';
    echo '<li>';
    echo '<p class="description">Check to delete</p>';
    
    foreach($attached_files as $attached_file){
        echo '<span class="full"><input type="checkbox" name="delete_files[]" value="'.$attached_file['id'].'"/>'.$attached_file['name'].' ('.$attached_file['version_string'].')</span>';
    }
    
    echo '</li>';
    echo '<li>';
    
    
    echo '<p class="description">Check to add</p>';
    
    $fb->show_tree();
    
    
    echo '</li>';
    echo '<input class="center button button-primary button-large" type="submit" value="Update"/>';
    echo '</ul>';
}

//Meta box save-ing
function news_save_custom_meta($post_id, $post) {
    if ( !wp_verify_nonce( $_POST['meta_noncename'], plugin_basename(__FILE__) )) {
	   return $post->ID;
	}

	//Check user level
	if ( !current_user_can( 'edit_post', $post->ID ))
		return $post->ID;

    update_post_meta($post->ID, 'project_id', $_SESSION['current_project_id']);
    
    $calendar = new calendar;
    
    //Delete FILES
    if(isset($_POST['delete_files']) && !empty($_POST['delete_files'])){
        $delete_files = $_POST['delete_files'];
        $calendar->disattach_file($post->ID, $delete_files);
    }
    
    //new FILE
    if(isset($_POST['add_files']) && !empty($_POST['add_files'])){
        $add_files = $_POST['add_files'];
        $calendar->attach_files($post->ID, $add_files);
    }
}
add_action('save_post', 'news_save_custom_meta', 1, 2); // save the custom fields


//Custom table columns
function news_custom_column($cols) {
    $new = array();
    foreach($cols as $key => $title) {
        if ($key=='date'){
            $new['project'] = __('Assigned to project');
        }
        $new[$key] = $title;
    }
    return $new;
}

//The custom columns
function news_custom_value($column_name, $post_id) {
    $project = new project;
    
    if($column_name == 'project'){
        echo $project->get_project_name(get_post_meta($post_id, "project_id", true));
    }
}
add_filter( 'manage_news_posts_columns', 'news_custom_column' );
add_action( 'manage_news_posts_custom_column', 'news_custom_value', 10, 2 );
?>
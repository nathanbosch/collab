<?php
if(!session_id()) {
    session_start();
}

//Includes
include_once('recent_activities_functions.php');
include_once('project_functions.php');
include_once('register.php');
include_once('projects.php');
include_once('helpers.php');
include_once('file_browser_functions.php');
include_once('calendar.php');
include_once('calendar_functions.php');
include_once('news.php');
include_once('news_functions.php');
include_once('public_pages.php');
include_once('public_pages_functions.php');
?>

<?php
////////////////////////////////////////////////////////////////////
//
//    Project: KNMI PMS 
//    Author: Nathan Bosch  
//    
//    Function: This file contains all possible functions for a 
//    project like groups, roles and modules.
//
////////////////////////////////////////////////////////////////////


class project{
    private $current_user_id;
    private $current_project_id;
    private $ra;
    
    private $roles_prefix = 'projects_';
    private $project_roles = array( 'client' => 'Client',
                                    'member' => 'Member',
                                    'manager' => 'Manager');
    
    function __construct(){
        $this->current_user_id = get_current_user_id();
        $this->current_project_id = $_SESSION['current_project_id'];
        
        //Create new classes
        $this->ra = new recent_activities;
        
        $this->get_user_projects_roles();
    }
    
    function show_contacts(){
        //Initialize vars
        $search_array = array();
        $search = '';
        $emailadresses = array();
        
        if(isset($_POST['search']) && !empty($_POST['search'])){
            $search = sanitize_text_field($_POST['search']);
            $search_array = explode(";",$search);
        }
        
        //Print search form
        echo "
        <form id='contacts_search' method='post'>
            <input type='text' list='groups' autocomplete='off' value='{$search}' name='search' id='search' placeholder='Search for...  (Use ; as delimiter for multiple keywords)'/>";
        
        //Print groups as suggestion
        echo "<datalist id='groups'>";
        foreach($this->get_project_user_groups() as $group){
            echo "<option value='{$group}'>";
        }
        echo "</datalist>";
        
        echo "
            <input type='submit' id='submit' value='Search'/>
        </form>
        ";
        
        //Print opening
        echo "<ul id='contacts'>";
        
        foreach($this->get_project_users_managers_details(null, $filter_group, $search_array) as $user){
            echo "<li>";
            echo "<img src='{$user['thumbnail']}'/>";
            echo "<span class='content'>";
            echo "<h1 class='name'>{$user['formal_name']}</h1>";
            echo "<p class='institute_function'>{$user['institute']} - {$user['function']}</p>";
            echo "<p class='role'>Project role: {$user['role']}</p>";
            echo "<p class='group'>Project group: {$user['group']}</p>";
            echo "<p class='email'>Emailadress: <a href='mailto:{$user['emailadress']}'>{$user['emailadress']}</a></p>";
            echo "<p class='phone'>Phone number: <a href='tel:{$user['phone_number']}'>{$user['phone_number']}</a></p>";
            echo "</span>";
            echo "</li>";
            
            array_push($emailadresses, $user['emailadress']);
        }
        
        //Print closeing
        echo "</ul>";
        
        $emailadresses_windows = implode(';',$emailadresses);
        $emailadresses_mac = implode(',',$emailadresses);
        
        //Print selection mail button
        echo "<div id='contact_action_buttons'>";
        echo "<a class='m_button' href='mailto:{$emailadresses_windows}'>Send email to this selection (Outlook)</a>";
        echo "<a class='m_button right' href='mailto:{$emailadresses_mac}'>Send email to this selection (Apple & Thunderbird)</a>";
        echo "</div>";
    }
    
    //Compare role based on 'level'
    function role_grater_than($role = null, $treshold_role = null){
        if($treshold_role == 'none'){
            return true;
        }
        
        if(empty($role) or empty($treshold_role)) return false;
        
        
        //Order role keys and attach a 'level'
        //0 for lowest role, to X for highest role
        $keyed_roles = array_flip(array_values(array_flip($this->project_roles)));
        
        if($keyed_roles[$role] >= $keyed_roles[$treshold_role]) return true;
        
        return false;
    }
    
    function get_current_project_id(){
        return $this->current_project_id;
    }
    
    function create_forum($post){
        $forum_data = apply_filters( 'bbp_new_forum_pre_insert', array(
            'post_author'    => $post->post_author,
            'post_title'     => $post->post_title,
            'post_parent'    => 0,
            'post_status'    => 'publish',
            'post_type'      => 'forum',
            'comment_status' => 'closed'
        ) );

        // Insert forum
        $forum_id = wp_insert_post( $forum_data );
        
        $this->project_attach_forum(null, $forum_id);
        
        return $forum_id;
    }
    
    function project_attach_forum($project_id = null, $forum_id){
        if($project_id == null) $project_id = $this->current_project_id;
        if($project_id == 0 or $forum_id == 0) return false;
        update_post_meta( $project_id, 'project_forum_id', $forum_id);   
        return true;
    }
    
    function get_forum_id($project_id = null){
        if($project_id == null) $project_id = $this->current_project_id;
        if($project_id == 0) return false;
        $forum_id = get_post_meta($project_id,'project_forum_id', true);
        if($forum_id == 0){
            $post->post_title = $this->get_project_name();
            $forum_id = $this->create_forum($post);
        }
        
        return $forum_id;
    }

    function get_project_name($project_id = null){
        if($project_id == null) $project_id = $this->current_project_id;
        if(!$this->project_exist($project_id)) return false;
        return get_the_title($project_id);
    }

    function get_project_logo($project_id){
        if(!$this->project_exist($project_id)) return false;
        return wp_get_attachment_url( get_post_thumbnail_id($project_id) );
    }
    
    function get_projects($user_id){
        $user_projects = array_keys($this->get_user_projects_roles($user_id));
        $all_projects = $this->get_all_projects();
        
        //Match with existing for security
        return array_intersect($user_projects, $all_projects);
    }
    
    function get_all_projects(){
        //Get existing projects
        $projects = get_posts(array('post_type' => 'projects','post_status' => 'publish','posts_per_page' => 9999));
        $return = array();
        foreach($projects as $project){
            array_push($return, $project->ID);
        }

        //If no projects assigned create empty array
        if(!is_array($projects)){
            $projects = array();
        }

        $return = array_unique($return);

        return $return;
    }
    
    function project_exist($project){
        //Get all existing projects
        $existing_projects = $this->get_all_projects();
        return in_array($project, $existing_projects);
    }
    
    function filter_existing_projects($projects){
        //Get all existing projects
        $existing_projects = $this->get_all_projects();
        return array_intersect($projects, $existing_projects);
    }
    
    function get_project_by_name($project_name){
        //If multiple, smallest id will be returned
        return get_page_by_title( $project_name, ARRAY_A, 'projects' )['ID'];    
    }

    //Project roles
    function get_roles(){
        return $this->project_roles;
    }
    
    function set_project_role($role, $project_id = null, $user_id = null){
        if($user_id == null) $user_id = $this->current_user_id;
        if($project_id == null) $project_id = $this->current_project_id;
        if($user_id == 0 or $project_id == 0) return false;
        
        //If role == none, delete all roles 
        if($role == 'none'){
            //Delete project for all other roles
            foreach($this->project_roles as $key => $delete_role){
                if($key == $role) continue;
                $this->delete_project_role($key, $project_id, $user_id);
            }
            return;
        }
        
        //If invalid role retur;
        if(!array_key_exists($role,$this->project_roles)) return false;
        
        //Get existing projects for role
        $existing_projects = $this->get_projects_with_role($role, $project_id, $user_id);
        if(!is_array($existing_projects)){
            $existing_projects = array();
        }
        
        //If not already assigned role to project 
        if(!in_array($project_id, $existing_projects)){
            
            
            //Delete other roles
            foreach($this->project_roles as $key => $delete_role){
                if($key == $role) continue;
                $this->delete_project_role($key, $project_id, $user_id);
            }
            
            //Save new role
            array_push($existing_projects, $project_id);
            $projects = array_unique($existing_projects);
            update_user_meta( $user_id, $this->roles_prefix.$role,  serialize($projects) );
            
        }
        
        return true;
        
    }
    
    function get_project_role($project_id = null, $user_id = null){
        if($user_id == null) $user_id = $this->current_user_id;
        if($project_id == null) $project_id = $this->current_project_id;
        if($user_id == 0 or $project_id == 0) return false;
        
        
        //Admin is almighty
        if(in_array('administrator', get_userdata($user_id)->roles)) return 'manager';
        
        $projects = $this->get_user_projects_roles($user_id);
        
        //If has role return
        if(array_key_exists($project_id, $projects)) return $projects[$project_id];
        return false;
    }
    
    function delete_project_role($role, $project_id = null, $user_id = null){
        if($user_id == null) $user_id = $this->current_user_id;
        if($project_id == null) $project_id = $this->current_project_id;
        if($user_id == 0 or $project_id == 0) return false;
        
        //Return is invalid role
        if(!array_key_exists($role,$this->project_roles)) return false;
        
        //Get projects with role
        $existing_projects = $this->get_projects_with_role($role, $project_id, $user_id);
        
        //If project already deleted return.
        if(!is_array($existing_projects) or !in_array($project_id, $existing_projects)){
            return false;
        };
        
        //Unset project form array
        $key = array_search($project_id,$existing_projects);
        unset($existing_projects[$key]);
        
        //SAve to DB
        update_user_meta( $user_id, $this->roles_prefix.$role,  serialize($existing_projects) );
        return true;
    }
    
    function get_projects_with_role($role, $project_id = null, $user_id = null){
        if($user_id == null) $user_id = $this->current_user_id;
        if($project_id == null) $project_id = $this->current_project_id;
        if($user_id == 0 or $project_id == 0) return false;
        
        //Get all project with specific role
        return unserialize(get_usermeta($user_id, $this->roles_prefix.$role));
    }
    
    function get_user_projects_roles($user_id = null){
        if($user_id == null) $user_id = $this->current_user_id;
        if($user_id == 0) return false;
        
        $return = array();
        
        //Loop all roles.
        //Return array with project_id as key and role as value
        foreach($this->project_roles as $key => $project_role){
            $projects = unserialize(get_usermeta($user_id, $this->roles_prefix.$key));
            if(!is_array($projects)){
                $projects = array();
            }
            foreach($projects as $project){
                $return[$project] = $key;
            }
        }
        return $return;
        
    }
    
    function get_users_with_project_role($role, $project_id = null){
        if($project_id == null) $project_id = $this->current_project_id;
        if($project_id == 0) return false;
        
        //Loop all users, select based on managed projects
        $all_users = get_users(array('orderby' => 'login'));

        $return = array();

        //Loop all users
        foreach ($all_users as $user) {
            $user_id = $user->ID;
            
            //Get projects of user
            $projects = $this->get_user_projects_roles($user_id);
            
            //If user matches on role, return user.
            if(array_key_exists($project_id, $projects)){
                if($projects[$project_id] == $role) array_push($return, $user_id);
            }
        }
        return $return;
        
    }
        
    function get_project_users($project_id){
        
        if($project_id == null) $project_id = $this->current_project_id;
        if($project_id == 0) return false;
        
        //Loop all users, select based on managed projects
        $all_users = get_users(array('orderby' => 'login'));

        $return = array();

        //Loop all users
        foreach ($all_users as $user) {
            $user_id = $user->ID;
            $projects = $this->get_user_projects_roles($user_id);
            
            //If users has any role return him
            if(array_key_exists($project_id, $projects)){
                array_push($return, $user_id);
            }
        }
        return $return;
    }
    
    function get_project_managers_email($project_id = null){
        if($project_id == null) $project_id = $this->current_project_id;
        if(!$this->project_exist($project_id)) return false;
        
        $managers = $this->get_project_users_managers_details($project_id);
        $emailadresses = array();
        
        foreach($managers as $manager){
            if($manager['role'] != 'manager') continue;
            array_push($emailadresses, $manager['emailadress']);
        }
        
        return implode(',',$emailadresses);
    }

    function get_project_users_managers_details($project_id = null, $filter_group = '', $search = array()){
        if($project_id == null) $project_id = $this->current_project_id;
        if(!$this->project_exist($project_id)) return false;
        
        //Merge and populate memebrs and managers
        $users_managers = $this->get_project_users($project_id);

        $returns = array();

        foreach($users_managers as $user_manager){

            $return = array();
            $return['formal_name'] = $this->get_user_formal_name($user_manager);
            $return['role'] = $this->get_project_role($project_id, $user_manager);
            $return['group'] = implode(', ',$this->get_project_groups($user_manager, $project_id));
            $return['emailadress'] = get_userdata($user_manager)->user_email;
            $return['phone_number'] = get_user_meta($user_manager, 'phone_number', true);
            $return['institute'] = get_user_meta($user_manager, 'institute', true);
            $return['function'] = get_user_meta($user_manager, 'function', true);

            //Filter by search term
            if(!empty($search)){
                $found = false;
                
                //Iterate all values
                foreach($return as $key => $value){
                    
                    //If match found we can stop searching
                    foreach($search as $search_item){
                        if(strpos(strtolower($value), strtolower($search_item)) !== FALSE){
                            $found = true;
                            continue;
                        }
                    }
                }
                
                //If nothing found skip it
                if(!$found) continue;
            }
            
            //Add after search to exclude from searching
            $return['id'] = $user_manager;
            $return['thumbnail'] = get_cupp_meta($user_manager, 250,250);

            array_push($returns, $return);
        }

        return $returns;
    }

    function get_user_formal_name($user_id = null){
        if($user_id == null) $user_id = $this->current_user_id;
        
        //Merge usermeta to string
        return get_usermeta($user_id, 'title')." ".get_usermeta($user_id, 'initials')." ".get_usermeta($user_id, 'last_name');
    }
    

    //Project groups
    function get_project_groups($user_id = null, $project_id = null){
        
        if($project_id == null) $project_id = $this->current_project_id;
        if($user_id == null) $user_id = $this->current_user_id;
        if(!$this->project_exist($project_id)) return false;
        
        //Get current groups
        $allgroups = unserialize(get_user_meta($user_id, 'project_groups', true));

        //Get group for project_id
        $projectgroups = $allgroups[$project_id];
       
        if(!is_array($projectgroups)){
            $projectgroups = array();
        }
        
        //Only let exsting groups pass.
        $projectgroups = array_intersect($this->get_project_user_groups($project_id), $projectgroups);
        
        //If no group then set group to none
        if(!is_array($projectgroups)) return array('none');
        return $projectgroups;
    }
    
    function update_project_groups($user_id, $project_id, $groups){
        if(!$this->project_exist($project_id)) return false;
        
        //Only let exsting groups pass.
        $groups = array_intersect($this->get_project_user_groups($project_id), $groups);
        
        $user_formal_name = $this->get_user_formal_name($user_id);
        $groups_name = $this->get_project_nice_name($groups);

        //All groups for each project and insert groups for this project.
        $all_groups = unserialize(get_user_meta($user_id, 'project_groups', true));
        
        //Return is groups are the same
        if($all_groups[$project_id] == $groups) return;
        
        $all_groups[$project_id] = $groups;
        
        //save data
        update_user_meta( $user_id, 'project_groups',  serialize($all_groups) );
        
        //Stringify for logging.
        $groups = implode(', ',$groups);
        
        //Logging
        $this->ra->log_activity('Changed user groups to: '.$groups.' for : '.$user_formal_name, $user_id);
       
    }

    function get_project_user_groups($project_id = null){
        $groups = array();
        
        if($project_id == null) $project_id = $this->current_project_id;
        if(!$this->project_exist($project_id)) return $groups;
        
        //Get current groups for project
        $groups = unserialize(get_post_meta($project_id,'groups', true));

        if(!is_array($groups)){
            $groups = array();
        }

        //Sort groups
        asort($groups);

        return $groups;
    }

    function update_project_user_groups($project_id,$new_groups){
        if(!$this->project_exist($project_id)) return false;
        
        if(!is_array($new_groups)){
            return false;
        }

        $corrected_new_groups = array();

        foreach($new_groups as $key => $new_group){
            //remove empty
            if(empty($new_group)){
                unset($new_groups[$key]);
                continue;
            }
            
            $new_group = str_replace(' ','_',$new_group);
            $new_group = strtolower($new_group);

            array_push($corrected_new_groups, $new_group);
        }

        $new_groups = $corrected_new_groups;

        //Get current groups
        $groups = $this->get_project_user_groups($project_id);

        //Merge with new groups
        $groups = array_unique(array_merge($groups, $new_groups));

        //Update groups
        update_post_meta($project_id,'groups',serialize($groups));
    }

    function delete_project_user_groups($project_id,$delete_groups){
        if(!is_array($delete_groups)){
            return false;
        }

        //Get current groups
        $groups = $this->get_project_user_groups($project_id);

        //Difference with new delete groups
        $groups = array_diff($groups, $delete_groups);

        //Update
        update_post_meta($project_id,'groups', serialize($groups));
    }

    function get_project_nice_name($project_name){
        if(is_array($project_name)){
            $returns = array();
            
            foreach($project_name as $item){
                array_push($returns,$this->get_project_nice_name($item));
            }
            
            return $returns;
        }
        else{
            $project_name = str_replace('_',' ',$project_name);
            $project_name = ucwords($project_name);

            return $project_name;
        }
    }

    //Modules
    function module_login_required($project_id = null, $module_id = null){
        if($project_id == null) $project_id = $this->current_project_id;
        if(!$this->project_exist($project_id)) return false;
        
        $module_rules = (get_post_meta($project_id, 'module_login_required', true));
        
        //No specefic rules? Get default
        if(empty($module_rules) or !is_array($module_rules)){
            $module_rules = unserialize(get_option('knmi_default_module_require_login', true));
        }
        
        if($module_id == null) return $module_rules;
        else return $module_rules[$module_id];
    }
    
    function set_module_login_required_rules($project_id = null, $rules){
        if($project_id == null) $project_id = $this->current_project_id;
        if(!$this->project_exist($project_id)) return false;
        
        //Get all modules
        $all_modules = array_keys($this->get_all_modules());

        //filter for valid rules
        $valid_rules = array_intersect($all_modules,$rules);
        
        
        
        //Holder for the saved rules
        $save_rules = array();
        
        //default everything false
        foreach($all_modules as $module){
            $save_rules[$module] = 'false';
        }
        
        //Change valid rules to 'true'
        foreach($valid_rules as $valid_rule){
            $save_rules[$valid_rule] = 'true';
        }
        
        
        //Save
        update_post_meta($project_id,'module_login_required',$save_rules);
        return true;
    }
    
    function update_project_modules($project_id, $modules){
        if(!$this->project_exist($project_id)) return false;
        
        if(!is_array($modules)){
            $modules = array();
        }



        //Get all modules
        $all_modules = array_keys($this->get_all_modules());
        $active_modules = $this->get_project_modules($project_id);

        //filter for valid modules
        $valid_modules = array_intersect($all_modules,$modules);

        //Calc delete and save modules
        $delete_modules = array_diff($active_modules, $valid_modules);
        $new_modules = array_diff($valid_modules, $active_modules);

        //Save new set
        $this->save_project_modules($project_id,$valid_modules);

        //Logging
        foreach($delete_modules as $delete_module){
            $this->ra->log_activity( 'Deleted module \''.$delete_module.'\'', $delete_module, $project_id);
        }

        foreach($new_modules as $new_module){
            $this->ra->log_activity('Added module \''.$new_module.'\'', $new_module,$project_id);
        }

    }

    function save_project_modules($project_id, $modules){
        if(!$this->project_exist($project_id)) return false;
        
        //Serialize
        $modules = serialize($modules);

        //Save modules
        update_post_meta($project_id,'modules',$modules);
    }

    function get_project_modules($project_id = null){
        if($project_id == null) $project_id = $this->current_project_id;
        if(!$this->project_exist($project_id)) return false;
        
        //Get current modules
        $modules = unserialize(get_post_meta($project_id,'modules', true));

        //If no modules assigned create empty array
        if(!is_array($modules)){
            $modules = array();
        }

        //Sort modules
        asort($modules);

        return $modules;
    }

    function project_has_module($project_id = null, $module_id){
        if($project_id == null) $project_id = $this->current_project_id;
        if(!$this->project_exist($project_id)) return false;
        
        if(in_array($module_id,$this->get_project_modules($project_id))) return true;

        return false;
    }

    function get_module_full_name($module_id){

        $modules = $this->get_all_modules();
        return $modules[$module_id];

    }

    function get_all_modules(){
        global $plugin_prefix;
        $modules = unserialize(get_option($plugin_prefix.'modules'));
        return $modules;
    }
}
?>
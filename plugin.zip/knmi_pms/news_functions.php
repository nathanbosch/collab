<?php
////////////////////////////////////////////////////////////////////
//
//    Project: KNMI PMS 
//    Author: Nathan Bosch  
//    
//    Function: This file contains all possible functions for  
//    news.
//
////////////////////////////////////////////////////////////////////

class news{
    
    private $project_id;
    private $fb;
    
    function __construct($project_id = null){
        if($project_id == null) $this->project_id = $_SESSION['current_project_id'];
        else $this->project_id = $project_id;
        
        $this->fb = new file_browser;
    }
    
    function show(){
        //Initialize 
        $news_id = sanitize_text_field($_GET['news_id']);
        
        //Show single article
        if(isset($news_id) && $news_id != ''){
            //Get article
            $article = $this->get_article($news_id);
            
            //Has access?
            if(!$article) return;
            
            //Initialize more vars
            $date = new DateTime($article['Date']);
            $date = $date->format('Y-m-d H:i');
            if(!is_array($article['attached_files'])){
                $article['attached_files'] = array();
            }
            
            //Populate files
            $files = $this->fb->get_all_files_info($article['attached_files']);
            
            //Print article openings
            echo "<div id='article'>";
            echo "<div id='left'>";
            echo "<img src='{$article['thumbnail']}'/>";
            
            //Loop attached files
            echo "<span class='files'><h2 class='title'>Attachment(s)</h2>";
            foreach($files as $file){
                //Some more initializing
                $time = new DateTime($file['time']);
                $time = $time->format('Y-m-d H:i');
                $extension = strtoupper(ltrim(strrchr($file['name'], '.'), '.'));
                
                //Print file
                echo "<div id='file'>";
                echo "<span class='extension'>{$extension}</span>";
                echo "<span class='right'>";
                echo "<p class='filename'>{$file['name']}</p>";
                echo "<p class='date'>{$time}</p>";
                
                //Print view and download buttons
                if($file['access']){
                    echo "<a href='/download/{$file['id']}' class='download'>Download</a>";
                    echo "<a href='/view/{$file['id']}' class='view'>View</a>";
                }
                else echo "<p class='no_access'>You have no access for this file.</p>";
                
                //Closeings
                echo "</span>";
                echo "</div>";
            }
            
            //Print the actual article
            echo "</span>";
            echo "</div>";
            echo "<div id='right'>";
            echo "<h1 class='title'>{$article['Title']}</h1>";
            echo "<p class='date'>Posted: {$date}</p>";
            echo "<p class='content'>{$article['Content']}</p>";
            echo "</div>";
            echo "</div>";

            return;
        }
        
        //Else print all articles
        
        //Print opening
        echo "<ul id='news'>";
        
        foreach($this->get_articles() as $article){
            //Initializing
            $article = $this->get_article($article);
            $date = new DateTime($article['Date']);
            $date = $date->format('Y-m-d H:i');
            if(!is_array($article['attached_files'])){
                $article['attached_files'] = array();
            }
            
            
            //Populate files
            $files = $this->fb->get_all_files_info($article['attached_files']);
            
            //Print article
            echo "<li><a href='/news/{$article['ID']}'>";
            echo "<img src='{$article['thumbnail']}'/>";
            echo "<span class='content'>";
            echo "<h1 class='title'>{$article['Title']}</h1>";
            echo "<p class='date'>Posted: {$date}</p>";
            echo "<p class='content'>{$this->excerpt($article['Content'])}</p>";
            
            //Iterate files
            echo "<span class='files'>Attachment(s): ";
            $file_names= array();
            foreach($files as $file){
                array_push($file_names, $file['name']);
            }
            echo implode(', ', $file_names);
            echo "</span>";
            echo "</span>";
            echo "</a></li>";
        }
        
        //Print closesing
        echo "</ul>";
    }
    
    function get_articles(){
        //Get all events
        $articles = $this->get_all_articles();
        $return = array();

        //Match event based on project id
        foreach($articles as $article){
            $article_project_id = get_post_meta($article, "project_id", true);
            if($article_project_id == $this->project_id) array_push($return, $article);
        }

        return $return;
    }

    function get_all_articles(){

        //Get existing events
        $articles = get_posts(array('post_type' => 'news','post_status' => 'publish'));

        //Push ID to return
        $return = array();
        foreach($articles as $article){
            array_push($return, $article->ID);
        }

        //Remove possible duplicates
        $return = array_unique($return);
        return $return;
    }

    function get_article($article_id){
        //access?
        if(!$this->has_acces_to_article($article_id)) return false;
        if(!$this->is_article($article_id)) return false;
        
        //Get event data
        $article_data = get_postdata($article_id);
        $article_meta = get_post_meta($article_id,NULL,true);

        //Take first value of arrays
        $article_meta_new = array();
        foreach($article_meta as $article_meta_key => $value){
            $article_meta_new[$article_meta_key] = $value[0];
        }
        $article_meta = $article_meta_new;


        $article = array_merge($article_data,$article_meta);
        


        //valid return options
        $valid_article_options = array(  'ID', 'Title', 'Category', 'Date','Content', 'attached_files');

        //Remove unvalid options for return
        $article = array_intersect_key($article,array_flip($valid_article_options));
        
        $article['attached_files'] = unserialize($article['attached_files']);
        $article['thumbnail'] = wp_get_attachment_url( get_post_thumbnail_id($article_id));

        return $article;
    }
    
    function has_acces_to_article($article_id){
        $project_id = get_post_meta($article_id,'project_id',true);
        if($project_id == $_SESSION['current_project_id']) return true;
        else return false;
        
    }
    
    function is_article($article_id){
        $post_type = get_post_type($article_id);
        if($post_type == 'news') return true;
        else return false;
        
    }
    
    function excerpt($input){
        $excerpt = strip_shortcodes($input);
        $excerpt = strip_tags($excerpt);
        $excerpt = substr($excerpt, 0, 700);
        $excerpt .= '[...]';
        return $excerpt;
    }
}
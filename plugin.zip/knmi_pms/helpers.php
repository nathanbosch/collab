<?php
////////////////////////////////////////////////////////////////////
//
//    Project: KNMI PMS 
//    Author: Nathan Bosch  
//    
//    Function: Just some general helper functions
//
////////////////////////////////////////////////////////////////////


//Try to find the right input type based on the fieldname
function get_input_type($fieldname){
    $type = 'text';

    if(strpos($fieldname,'time') !== false){
        $type = "time";
    }

    elseif(strpos($fieldname,'date') !== false){
        $type = "date";
    }

    elseif(strpos($fieldname,'mail') !== false){
        $type = "email";
    }

    elseif(strpos($fieldname,'tel') !== false || strpos($fieldname,'phone') !== false){
        $type = "tel";
    }

    elseif(strpos($fieldname,'number') !== false){
        $type = "number";
    }
    
    return $type;
}

function remove_timestamp($input){
    if(is_array($input)){
        $output = array();
        foreach($input as $item){
            $length = strlen($item['name']) + 11;
            $item['nice_path'] = substr($item['path'], 0, 0 - ($length));
            $item['nice_path'] = $item['nice_path'].$item['name'];
            array_push($output, $item);
        }
    }
    
    else{
        $length = strlen($input['name']) + 11;
        $input['path'] = substr($input['path'], 0, 0 - ($length));
        $input['nice_path'] = $input['nice_path'].$input['name'];
        $output = $input;
    }
    
    
    return $output;
}
function add_folder_level($input){
    if(is_array($input)){
        $output = array();
        foreach($input as $item){
            $item['level'] = substr_count($item['path'], '/');
            array_push($output, $item);
        }
    }
    
    else{
        $input['level'] = substr_count($input['path'], '/');
        $output = $input;
    }
    return $output;
}
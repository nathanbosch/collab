<?php
////////////////////////////////////////////////////////////////////
//
//    Project: KNMI PMS 
//    Author: Nathan Bosch  
//    
//    Function: This files handles the NEWS custom post type, 
//    including the saving and retrieving of the custom metafields
//
////////////////////////////////////////////////////////////////////


//Build news post type
function public_pages_post_type() {
	$labels = array(
	  'name' => _x('Public pages', 'Cpost type general name'),
	  'singular_name' => _x('Public page', 'Cpost type singular name'),
	  'add_new' => _x('Add new', 'Public page'),
	  'add_new_item' => __('Add new public page'),
	  'edit_item' => __('Edit public page'),
	  'new_item' => __('New public page'),
	  'view_item' => __('View public page'),
	  'search_items' => __('Find public page'),
	  'not_found' =>  __('No public pages found'),
	  'not_found_in_trash' => __('No pubic pages found in bin')
	);
	$args = array(
	  'labels' => $labels,
	  'public' => true,
	  'publicly_queryable' => true,
	  'show_ui' => true,
	  'exclude_from_search' => false,
	  'query_var' => true,
	  'rewrite' => array( 'slug' => 'public_page' ),
        'capabilities' => array(
            'edit_post' => 'edit_public_page',
            'edit_posts' => 'edit_public_page',
            'edit_others_posts' => 'edit_other_public_pages',
            'publish_posts' => 'publish_public_pages',
            'read_post' => 'read_public_pages',
            'read_private_posts' => 'read_private_public_pages',
            'delete_post' => 'delete_public_page'
        ),
	  'hierarchical' => false,
	  'menu_position' => 20,
      'menu_icon' => 'dashicons-welcome-view-site',
	  'supports' => array('title','editor','thumbnail')
	);
	register_post_type('public_pages',$args);
	
	
}
add_action( 'init', 'public_pages_post_type' );

//Custom table columns
function public_pages_custom_column($cols) {
    $new = array();
    foreach($cols as $key => $title) {
        if ($key=='date'){
            $new['project'] = __('Assigned to project');
        }
        $new[$key] = $title;
    }
    return $new;
}

//The custom columns
function public_pages_custom_value($column_name, $post_id) {
    $project = new project;
    
    //The functie
    if($column_name == 'project'){
        echo $project->get_project_name(get_post_meta($post_id, "project_id", true));
    }
}
add_filter( 'manage_public_pages_posts_columns', 'public_pages_custom_column' );
add_action( 'manage_public_pages_posts_custom_column', 'public_pages_custom_value', 10, 2 );
?>
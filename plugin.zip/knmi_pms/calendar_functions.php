<?php
////////////////////////////////////////////////////////////////////
//
//    Project: KNMI PMS 
//    Author: Nathan Bosch  
//    
//    Function: This file contains all possible functions for a 
//    events.
//
////////////////////////////////////////////////////////////////////

class calendar{
    
    private $current_project_id;
    private $fb;
    
    
    
    function __construct(){
        $this->current_project_id = $_SESSION['current_project_id'];
        
        $this->fb = new file_browser;
    }
    
    function show(){
        //Initialize 
        $event_id = sanitize_text_field($_GET['event_id']);
        
        //Show single event
        if(isset($event_id) && $event_id != ''){
            //Initialize vars
            $event_data = $this->get_event($event_id);
            $start_date = new DateTime($event_data['start_date']);
            $start_date = $start_date->format('F d');
            $end_date = new DateTime($event_data['end_date']);
            $end_date = $end_date->format('F d');
            
            //Populate fiels
            $files = $this->fb->get_all_files_info($event_data['attached_files']);
            
            //Print event content
            echo "<div id='event'>";
            echo "<div id='content'>";
            echo "<h1>{$event_data['Title']}</h1>{$event_data['Content']}</div>";
            echo "<div id='date_time'>";
            if($start_date == $end_date){
                echo "<span class='date'>{$start_date}</span>";
            }
            else{
                echo "<span class='date'>{$start_date}<br/><small>till</small><br/>{$end_date}</span>";
            }
                
            echo "<span class='time'>{$event_data['start_time']} - {$event_data['end_time']}</span></div>";
            echo "<div class='files'>";
            
            //Loop files
            foreach($files as $file){
                //Some more initializing
                $extension = strtoupper(ltrim(strrchr($file['name'], '.'), '.'));
                $time = new DateTime($file['time']);
                $time = $time->format('Y-m-d H:i');
                
                //Print file
                echo "<div id='file'>";
                echo "<span class='extension'>{$extension}</span>";
                echo "<span class='right'>";
                echo "<p class='filename'>{$file['name']}</p>";
                echo "<p class='date'>{$time}</p>";
                
                //Print view and download buttons
                if($file['access']){
                    echo "<a href='/download/{$file['id']}' class='download'>Download</a>";
                    echo "<a href='/view/{$file['id']}' class='view'>View</a>";
                }
                else echo "<p class='no_access'>You have no access for this file.</p>";
                
                //Closeings
                echo "</span>";
                echo "</div>";
            }
            
            //Print maps and closeings
            echo "</div>";
            echo "<iframe class='google_maps' src='".$event_data['g_maps']."'></iframe>";
            echo "<div id='clear'></div>";
            echo "</div>";


            return;
        }
        
        //Else print the calendar
        $events = array();
        
        //Populate evets
        foreach($this->get_events() as $event){
            $event_data = $this->get_event($event);
            $event_data['end_date'];
            
            if($event_data['end_date'] == 0 or $event_data['end_date'] == ''){
                $event_data['end_date'] = $event_data['start_date'];
            }
            
            //If has time add it
            if($event_data['start_time'] != 0 && $event_data['end_time'] != 0){
                $event_item = " {title: '{$event_data['Title']}', 
                                start: '{$event_data['start_date']}T{$event_data['start_time']}',
                                end: '{$event_data['end_date']}T{$event_data['end_time']}',
                                url: '{$event_data['url']}'}";
            }
            
            //Else all day long event
            else{
                $event_item = " {title: '{$event_data['Title']}', 
                                start: '{$event_data['start_date']}',
                                end: '{$event_data['end_date']}',
                                url: '{$event_data['url']}'}";
            }
                
            //Add event
            array_push($events, $event_item);
        }
        
        //To string
        $events = implode(',',$events);
        
        //Generate js
        echo " <script>$(document).ready(function() { $('#calendar').fullCalendar({ header: { left: 'prev,next today', center: 'title', right: 'month,agendaWeek,agendaDay' }, editable: false, eventLimit: false, events: [ {$events} ] }); });</script><div id='calendar'></div>
        ";
    }

    function get_events($project_id = null){
        if($project_id == null) $project_id = $this->current_project_id;
        
        //Get all events
        $events = $this->get_all_events();
        $return = array();

        //Match event based on project id
        foreach($events as $event){
            $event_project_id = get_post_meta($event, "project_id", true);
            if($event_project_id == $project_id) array_push($return, $event);
        }

        return $return;
    }

    function get_all_events(){

        //Get existing events
        $events = get_posts(array('post_type' => 'calendar','post_status' => 'publish'));

        //Push ID to return
        $return = array();
        foreach($events as $event){
            array_push($return, $event->ID);
        }

        //Remove possible duplicates
        $return = array_unique($return);

        return $return;
    }

    function get_event($event_id){
        if(!$this->has_acces_to_event($event_id)) return false;
        if(!$this->is_event($event_id)) return false;
        
        //Get event data
        $event_data = get_postdata($event_id);
        $event_meta = get_post_meta($event_id,NULL,true);

        //Take first value of arrays
        $event_meta_new = array();
        foreach($event_meta as $event_meta_key => $value){
            $event_meta_new[$event_meta_key] = $value[0];
        }
        $event_meta = $event_meta_new;


        $event = array_merge($event_data,$event_meta);
        
        //valid return options
        $valid_event_options = array( 'ID', 'Content', 'Title', 'Category', 'post_name', 'start_date', 'end_date', 'start_time', 'end_time', 'street', 'number', 'city', 'country', 'attached_files');

        //Remove unvalid options for return
        $event = array_intersect_key($event,array_flip($valid_event_options));

        //Add permalink
        $event['url'] = site_url().'/calendar/'.$event['ID'];

        //Add maps
        $event['g_maps'] = '';

        if(!empty($event['city']) or !empty($event['country'])){
            $adress = $event['street'].' '.$event['number'].' '.$event['city'].' '.$event['country'];
            $event['g_maps'] = 'https://www.google.com/maps/embed/v1/place?key=AIzaSyAkmgJjvXQEwXPJO1-lNiYJf_Mt488kY5U&q='.$adress;
        }

        $event['attached_files'] = unserialize($event['attached_files']);
        
        return $event;
    }
    
    function has_acces_to_event($event_id){
        $project_id = get_post_meta($event_id,'project_id',true);
        if($project_id == $_SESSION['current_project_id']) return true;
        else return false;
        
    }
    
    function is_event($event_id){
        $post_type = get_post_type($event_id);
        if($post_type == 'calendar') return true;
        else return false;
        
    }
    
    function get_attached_files($event_id){
        
        //Get existing projects
        $attached_files = (get_post_meta($event_id, 'attached_files', true));
        

        //If no projects assigned create empty array
        if(!is_array($attached_files)){
            $attached_files = array();
        }
        
        return $attached_files;
    }
    
    function disattach_file($event_id, $disattach_files){
        //Get attached files
        $attached_files = $this->get_attached_files($event_id);

        //Remove  files from array
        $attached_files = array_diff($attached_files, $disattach_files);

        //Save option
        update_post_meta( $event_id, 'attached_files',  ($attached_files) );
        
    }
    
    function attach_files($event_id, $new_attached_files){
        //Get attached files
        $attached_files = $this->get_attached_files($event_id);

        //Add new files to array
        $attached_files = array_merge($attached_files, $new_attached_files);

        //Remove duplicates
        $attached_files = array_unique($attached_files);
        
        //Save option
        update_post_meta( $event_id, 'attached_files',  ($attached_files) );
    }
}
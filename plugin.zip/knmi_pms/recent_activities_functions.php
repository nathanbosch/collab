<?php
////////////////////////////////////////////////////////////////////
//
//    Project: KNMI PMS 
//    Author: Nathan Bosch  
//    
//    Function: This file contains all possible functions for  
//    recent activities.
//
////////////////////////////////////////////////////////////////////

class recent_activities{
    
    private $project_id;
    private $project;
    
    function __construct($project_id = null){
        //General post actiona hook
        add_action( 'post_updated', array($this, 'log_update_post'), 10, 3 );
        
        //Foru action hooks
        add_action( 'bbp_new_topic', array($this, 'log_new_topic'), 10, 3 );
        add_action( 'bbp_edit_topic', array($this, 'log_edit_topic'), 10, 3 );
        add_action( 'bbp_new_reply',  array($this, 'log_new_reply'), 10, 3 );
        add_action( 'bbp_edit_reply', array($this, 'log_edit_reply'), 10, 3 );
        
        if($project_id == null) $this->project_id = $_SESSION['current_project_id'];
        
        $this->user_id = get_current_user_id();
    }
    
    function show(){
        //Print start
        echo "<ul id='recent_activities'>";
        
        $current_date = 0;
        
        $opened = false;
        
        //Iterate the log
        foreach($this->get_log() as $item){
            
            //Format datetime
            $datetime = new DateTime($item['time']);
            $date = $datetime->format('l d F Y');
            $time = $datetime->format('H:i');
            
            //Print new date label?
            if($current_date !== $date){
                $current_date = $date;
                if($opened) echo "</ul>";
                $opened = true;
                echo "<ul><h1 class='date'>{$date}</h1>";
            }
            
            //More formatting
            $item['action'] = strtolower($item['action']);
            $user = $this->get_user_formal_name($item['user_id']);
            
            //Print log-line
            echo "<li>";
            echo $time." | ".$user." ".$item['action'];     
            echo "</li>";
        }
        
        //Print closeing
        echo "</ul>";
        echo '</ul>';
    }
    
    //Get id of item logged within the last second
    function last_item_id(){
        global $wpdb;

        $sql = $wpdb->prepare( 
                                        "
                                        SELECT item_id
                                        FROM knmi_recent_activities
                                        WHERE project_id = %d
                                        AND time > NOW() - INTERVAL 1 second
                                        ORDER BY time DESC
                                        LIMIT 1
                                        ",  
                                            array(
                                                $this->project_id
                                            ) 
                                        );
        
        //Do query
        $result = $wpdb->get_row($sql,ARRAY_A);

        
        return($result['item_id']);
    }

    function log_activity($action, $item_id){
        //Prevent duplicate actions
        if($item_id == $this->last_item_id()) return;
        
        
        //Security
        $user_id = intval($this->user_id);
        $project_id = intval($this->project_id);


        //Prepare query
        $plugin_prefix = 'knmi_';
        global $wpdb;

        $query = $wpdb->prepare( 
                                "
                                    INSERT INTO {$plugin_prefix}recent_activities
                                    ( user_id, action, item_id, project_id)
                                    VALUES ( %d, %s, %d, %d )
                                ",  
                                    array(
                                        $user_id, 
                                        $action,
                                        $item_id,
                                        $project_id
                                    ) 
                                );

        //Do query
        $wpdb->query($query);
    }

    //Get last X logged items
    function get_log($limit_items = 155) {
        
        
        
        global $wpdb;

        $sql = $wpdb->prepare( 
                                        "
                                        SELECT * 
                                        FROM knmi_recent_activities
                                        WHERE project_id = %d
                                        ORDER BY time DESC
                                        LIMIT %d
                                        ",  
                                            array(
                                                $this->project_id,
                                                $limit_items
                                            )
                                        );
        
        $results = $wpdb->get_results($sql,ARRAY_A);

        
        //Add type to logged items
        foreach($results as $key => $result){
            $result['type'] = get_post_type($result[item_id]);
            $results[$key] = $result;
        }

        return($results);
    }

    //Log an update of an posttpye // not projects
    function log_update_post($post_ID, $post, $update){
        if(get_post_type($post_ID) == 'projects') return;
        
        $post_name = get_the_title($post_ID);
        $post_type = get_post_type($post_ID);
       
        if($update)
            $this->log_activity('Edited '.$post_type.': '.$post_name, $post_ID, $this->project_id);
        else
            $this->log_activity('Created '.$post_type.': '.$post_name, $post_ID, $this->project_id);
    }

    //Logg forum, topics and replies
    function log_new_topic($topic_id){
        $name = get_the_title($topic_id);
        $this->log_activity('created new topic: '.$name, $topic_id, $this->project_id);
    }
    function log_edit_topic($topic_id){
        $name = get_the_title($topic_id);
        $this->log_activity('edited topic: '.$name, $topic_id, $this->project_id);
    }
    function log_new_reply($topic_id){
        $name = get_the_title($topic_id);
        $this->log_activity('added '.$name, $topic_id, $this->project_id);
    }
    function log_edit_reply($topic_id){
        $name = get_the_title($topic_id);
        $this->log_activity('edited '.$name, $topic_id, $this->project_id);
    }


    function get_user_formal_name($user_id = null){
        if($user_id == null) $user_id = $this->current_user_id;
        
        //Merge usermeta to string
        return get_usermeta($user_id, 'title')." ".get_usermeta($user_id, 'initials')." ".get_usermeta($user_id, 'last_name');
    }
}
?>
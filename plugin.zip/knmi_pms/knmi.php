<?php
/*
Plugin Name: KNMI Project Managment System
Plugin URI: 
Description: An KNMI internship developt PMS system. For documentation please see the design document and the thesis. (Supervisor Dr. R.J. Haarsma)
Version: 1.0
Author: Nathan Bosch
Author URI: http://www.nathanbosch.nl
*/




//Includes
include_once('classes.php');

//Prevent strange redirecting behavior
remove_filter('template_redirect', 'redirect_canonical');

//Activation hooks
register_activation_hook( __FILE__, 'activation' );
register_deactivation_hook( __FILE__, 'deactivation' );



//Load admin stylesheet
function load_style() {
    wp_register_style( 'knmi_'.'style', plugins_url( 'admin-style.css', __FILE__ ), false, '1.0.0' );
    wp_enqueue_style( 'knmi_'.'style' );
    wp_enqueue_script( 'jQuery-1.12.2', plugins_url( 'jquery.min-1.12.2.js', __FILE__ ), false );
    wp_register_style( 'knmi_'.'fa', plugins_url( 'fa-style.css', __FILE__ ), false, '1.0.0' );
    wp_enqueue_style( 'knmi_'.'fa' );
    
}
add_action( 'admin_enqueue_scripts', 'load_style' );

//Load calendar scripts
function load_style_front_end() {
    wp_enqueue_style( 'fullcalendar', plugins_url( 'fullcalendar/fullcalendar.css', __FILE__ ), false ); 
    wp_enqueue_script( 'fucalendar_js', plugins_url( 'fullcalendar/lib/moment.min.js', __FILE__ ), false );
    wp_enqueue_script( 'fucalendar_jquery', plugins_url( 'fullcalendar/lib/jquery.min.js', __FILE__ ), false );
    wp_enqueue_script( 'fucalendar_jquery_min', plugins_url( 'fullcalendar/fullcalendar.min.js', __FILE__ ), false );
    
}
add_action( 'wp_enqueue_scripts', 'load_style_front_end' );

function activation(){
    
    //User can register themselves
    update_option('users_can_register',1);
    
    //Set default user role
    update_option('default_role', 'knmi_'.'project_client');
    
    //Remove default Wordpress roles
    remove_role( 'editor');
    remove_role( 'author');
    remove_role( 'subscriber');
    remove_role( 'contributor');
    
    //Add custom user roles (waterfall, so adding capabilities each role)
    $capabilities = array('read' => true);
    add_role( 'knmi_'.'project_client', 'Project client', $capabilities);
    add_role( 'knmi_'.'project_user', 'Project user', $capabilities);
    
    $capabilities = array_merge($capabilities, array(   'edit_event' => true,
                                                        'edit_events' => true,
                                                        'publish_events' => true,
                                                        'read_events' => true,
                                                        'edit_other_events' => true,
                                                        'read_private_events' => true,
                                                        'delete_event' => true,
                                                        
                                                        'edit_article' => true,
                                                        'edit_articles' => true,
                                                        'publish_articles' => true,
                                                        'read_articles' => true,
                                                        'edit_other_articles' => true,
                                                        'read_private_articles' => true,
                                                        'delete_article' => true,
                                                    
                                                        'edit_project' => true,
                                                        'edit_projects' => true,
                                                        'read_project' => true,
                                                        'edit_other_projects' => true,
                                                        'read_private_projects' => true,
                                                        
                                                        'edit_public_page' => true,
                                                        'edit_public_page' => true,
                                                        'publish_public_pages' => true,
                                                        'read_public_pages' => true,
                                                        'edit_other_public_pages' => true,
                                                        'read_private_public_pages' => true,
                                                        'delete_public_page' => true,
                                                    
                                                        'upload_files' => 'true',
                                                    
                                                    
                                                        'edit_others_topics' => 'true',
                                                        'delete_others_topics' => 'true',
                                                        'edit_others_replies' => 'true',
                                                        'delete_others_replies' => 'true',
                                                        'moderate' => true));

    add_role( 'knmi_'.'project_manager', 'Project manager', $capabilities);
    
    $capabilities = array_merge($capabilities, array(   
                                                        'delete_project' => true,
                                                        'publish_projects' => true,
                                                        'edit_pages' => false,
                                                        'edit_posts' => false));
    
    //Administrator capabilities edit
    $role = get_role( 'administrator' );
    foreach($capabilities as $key => $capability){
        if($capability) $role->add_cap($key);
        elseif(!$capability) $role->remove_cap($key);
    }
    
    //Add modules to database
    $modules = array(   'about' => 'About',
                        'recent_activities' => 'Recent activities',
                        'news' => 'News',
                        'calendar' => 'Calendar',
                        'file_browser' => 'Files',
                        'contacts' => 'Contacts',
                        'discussion' => 'Discussion',
                        'public_pages' => 'Public Pages');
    
    $modules = serialize($modules);
    update_option('knmi_'.'modules', $modules);
    
    //Module minimal project role
    $module_minimal_role = array(   'about' => 'client',
                                    'recent_activities' => 'member',
                                    'news' => 'member',
                                    'calendar' => 'member',
                                    'file_browser' => 'client',
                                    'contacts' => 'client',
                                    'discussion' => 'member',
                                    'public_pages' => 'none');
    
    $module_minimal_role = serialize($module_minimal_role);
    update_option('knmi_'.'module_minimal_role', $module_minimal_role);
    
    //Module require login
    $default_module_require_login = array(   'about' => 'true',
                                    'recent_activities' => 'true',
                                    'news' => 'true',
                                    'calendar' => 'true',
                                    'file_browser' => 'true',
                                    'contacts' => 'true',
                                    'discussion' => 'true',
                                    'public_pages' => 'false');
    
    $default_module_require_login = serialize($default_module_require_login);
    update_option('knmi_'.'default_module_require_login', $default_module_require_login);
    
    //Add recent activities table to database
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE knmi_recent_activities (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      time timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
      user_id mediumint(9) NOT NULL,
      action text NOT NULL,
      item_id text NOT NULL,
      project_id mediumint(9) NOT NULL,
      UNIQUE KEY id (id)
    ) $charset_collate;";
    
    
    //Add files table to database
    $sql_files = "CREATE TABLE knmi_files (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      base_file_id mediumint(9),
      project_id mediumint(9) NOT NULL,
      time timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
      name text NOT NULL,
      path text NOT NULL,
      type text NOT NULL,
      version mediumint(9) DEFAULT 1,
      version_string text,
      UNIQUE KEY id (id)
    ) $charset_collate;";
    
    
    //Add folder_access table to database
    $sql_folder = "CREATE TABLE knmi_folder_access (
      folder_id mediumint(9) NOT NULL,
      groups text NOT NULL,
      UNIQUE KEY folder_id (folder_id)
    ) $charset_collate;";
    
    
    
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
    dbDelta( $sql_files );
    dbDelta( $sql_folder );
    
    //Replace .htaccess file
    update_htaccess();
}

//Update htaccess on action hook call
function update_htaccess(){
   $htaccess_default_file = plugin_dir_path( __FILE__ ).'htaccess.default';
   $htaccess_target_file = ABSPATH.'.htaccess';
   unlink($htaccess_target_file);
   $default_content = file_get_contents($htaccess_default_file);
   file_put_contents($htaccess_target_file, $default_content);
}
add_filter('mod_rewrite_rules', 'update_htaccess');

function deactivation(){
    //User can't register themselves
    update_option('users_can_register',0);
    
    //Remove custom user roles.
    remove_role( 'knmi_'.'project_manager');
    remove_role( 'knmi_'.'project_user');
    remove_role( 'knmi_'.'project_client');
    
    //Delete modules from database
    delete_option('knmi_'.'modules');
}


//Check if forum, topic or reply is connected to current project. Else redirect;
function check_forum_access($forum_id){
    $project = new project;
    if($forum_id != $project->get_forum_id()){
        if(!is_admin()){
            wp_redirect( home_url().'/discussion' );
            exit;
        }
        return;
    }
    return $forum_id;
}
add_filter('bbp_get_forum_id', 'check_forum_access');


//Sessions
add_action('init', 'StartSession', 1);
add_action('wp_logout', 'EndSession');
add_action('wp_login', 'EndSession');

function StartSession() {
    if(!session_id()) {
        session_start();
    }
}

function EndSession() {
    session_destroy ();
}

//General login check
add_action( 'wp', 'check_logged_in', 1);
function check_logged_in(){
    $project = new project;
    //Fix for about, only access if in the right project
	if(substr($_SERVER['REQUEST_URI'], 0, strlen('/project/')) === '/project/')	{
		if($_SESSION['current_project_id'] != get_the_ID()){
            wp_redirect(home_url());
        } 
	}
    if(is_user_logged_in()) return;
    $module = sanitize_text_field($_GET['page']);

    if($module == '') $module = 'public_pages';
    
	//Fix for about
	if(substr($_SERVER['REQUEST_URI'], 0, strlen('/project')) === '/project')	{
		$module = 'about';
	}
    
    $login_required = $project->module_login_required(null, $module);
    
    if(is_page('login')){
        return;
    }
    elseif($login_required == 'false'){
        return;
    }
    elseif($login_required == 'true'){
        session_unset();
        auth_redirect();exit;
    }
}

//Force to select a project
add_action('wp', 'project_selector', 2);
add_action('admin_menu', 'project_selector', 2);

function project_selector(){
    $project = new project;
    
    //Is project change requested redirect
    if(isset($_GET['change_project'])){
        session_unset();
        wp_redirect( home_url() );
        exit;
    }
    
    if(isset($_GET['project'])){
        $project = $project->get_project_by_name(str_replace('/','',$_GET['project']));
        if($project){
            $_SESSION['current_project_id'] = $project;
        }
        return;
        exit;
    }
    
    //If project selected return
    if($_SESSION['current_project_id']){
        return;
    }
    
    //If project requested select it
    if(isset($_POST['project'])){
        $project_id = intval($_POST['project']);
        if(empty($project_id)) return;
        $_SESSION['current_project_id'] = $project_id;
        
        //If admin skip this function
        if(in_array('administrator', wp_get_current_user()->roles)) return;
        
        //Assign right user role
        $user = new WP_User( get_current_user_id() );
        switch ($project->get_project_role($project_id)) {
            case "client":
                $user->set_role( 'knmi_project_client' );
                break;
            case "member":
                $user->set_role( 'knmi_project_user' );
                break;
            case "manager":
                $user->set_role( 'knmi_project_manager' );
                break;
            default:
                $user->set_role( 'knmi_project_client' );
        }
        return;
    }
    
    //If no projects redirect to admin
    $var = $project->get_all_projects();
    if(empty($var)){
        if(!is_admin()){
            wp_redirect( site_url('wp-admin') ); 
            exit; 
        }
    }
    
    $user_projects = $project->get_all_projects();
    
    
    //Print project selector and exit to prevent further code from running
    ?>
	<meta name="viewport" content="width=device-width">
    <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/style.css" media="screen" />
        <body class='project_select'>
            <form id="select_project" method="post" onchange='this.submit()'>
                <h1>Please select the project you want to use.</h1>
                <?php
    
                //If no projects
                if(empty($user_projects)){
                    echo '<div class="error">You have no projects assigned.</div>';
                }

                foreach($user_projects as $user_project){

                    echo "
                            <label>
                                <input type='radio' id='project' name='project' value='{$user_project}'/>
                                <img src='{$project->get_project_logo($user_project)}'/>
                                <p class='title'>{$project->get_project_name($user_project)}</p>
                            </label>


                            ";

                }
                ?>

            </form>       
        </body>
    <?php
    exit;
    
    //Print project selector and exit to prevent further code from running
    ?>
    <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/style.css" media="screen" />
        <form id="select_project" method="post" >
            <label for="project">Please select a project</label>
            <select id="project" name="project">
                <?php
                foreach($user_projects as $user_project){
                    echo '<option value="'.$user_project.'">'.$project->get_project_name($user_project).'</option>';
                }
                ?>
            </select>
            <input type="submit" value="Select"/>
        </form>            
    <?php
    exit;
}

//User account customization
add_filter('user_contactmethods', 'custom_contact_methods');

//ONLY USERNAME, EMAILADRESS AND PASSWORD WILL BE USED FROM WORDPRESS
function custom_contact_methods($profile_fields) {
    //Clear all field
    $profile_field = array();
    
	//Add new fields
	$profile_fields['title'] = 'Title (e.g. dr.)';
	$profile_fields['initials'] = 'Initials';
	$profile_fields['last_name'] = 'Lastname';
	$profile_fields['phone_number'] = 'Phone number';
	$profile_fields['institute'] = 'Institute';
	$profile_fields['function'] = 'Function';
    
	return $profile_fields;
}


//Filter all custom posts so one can only edit posts for the selected project
//Except admin, admin can access all
add_filter( 'posts_results', 'filter_results') ;
function filter_results( $posts )
{
    //Admin access all
    if(in_array('administrator',wp_get_current_user()->roles)) return $posts;
    
    $project = new project;
    global $typenow;
    global $pagenow;
    
    //Pass forums
    if( $pagenow == 'edit.php' && ($typenow == 'forum' )){
       return $posts;
    }
    
    //If not project filter bt current project id
    elseif( $pagenow == 'edit.php' && $typenow != 'projects'){
        foreach($posts as $key => $post){
            if(get_post_meta($post->ID,'project_id', true) != $project->get_current_project_id()){
                unset($posts[$key]);
            }

        }
    }
    
    //If project, filter by managed projects
    elseif( $pagenow == 'edit.php' && $typenow == 'projects'){
        $projects = $project->get_projects_with_role('manager');
        
        //No projects, show none
        if(empty($projects)) $projects = array(0);
        
        foreach($posts as $key => $post){
            if(!in_array($post->ID,$projects)){
                unset($posts[$key]);
            }
        }
    }
    
    //Fallback return all posts.
    return $posts;
    
}

//Remove link builder (secutiry issue)
function myplugin_tinymce_buttons($buttons){
    //Items to remove
    $removes = array('link','unlink');

    //Interate itemss
    foreach($removes as $remove){
        //Find and unset
        if ( ( $key = array_search($remove,$buttons) ) !== false )
        unset($buttons[$key]);
    }
    
    //Return valdis
    return $buttons;
}
add_filter('mce_buttons','myplugin_tinymce_buttons');


?>

<?php
////////////////////////////////////////////////////////////////////
//
//    Project: KNMI PMS 
//    Author: Nathan Bosch  
//    
//    Function: This file handles the user registration procedure,
//    verifies user input and sends the email when a new registration is made.
//
////////////////////////////////////////////////////////////////////

//Valid options
$valid_options = array(
                'title' => 'Title',
                'initials' => 'Initials',
                'last_name' => 'Lastname',
                'phone_number' => 'Phone number',
                'institute' => 'Institue',
                'function' => 'Function'
                );


//Customize registration form
add_action( 'register_form', 'custom_register_form' );

function custom_register_form() {
    
    //Import valid options
    global $valid_options;
    
    
    //Valid data placeholder
    $data = array();
    
    //Validate $_POST against valid options
    foreach( $_POST as $item => $value ) {
        if(array_key_exists($item, $valid_options)){
            $value = ( ! empty( $value ) ) ? trim( $value ) : '';
            $data[$item] = sanitize_text_field($value);
        }
    }   
    
    $pref_project_id = 0;
    if(isset($_POST['project'])){
        $pref_project_id = intval($_POST['project']);
    }
    
    $pref_group_id = 0;
    if(isset($_POST['group'])){
        $pref_group_id = $_POST['group'];
    }
    
    //Import $projects
    $project = new project;
    $all_projects = $project->get_all_projects();
    $all_groups = $project->get_project_user_groups($pref_project_id);
    
    
    
    
    //Echo the projects
    ?>
    <p>
        <label for="project">I want access to project:<br />
            <select onchange="this.form.submit()" name="project" class="input">
                <option value="">Choose a project</option>
                <?php
                //Print all projects
                foreach($all_projects as $project_id){
                    $project_name = $project->get_project_name($project_id);
                    echo "<option value=\"$project_id\"";
                    if($project_id == $pref_project_id) echo " selected ";
                    echo ">$project_name</option>";
                } 
                ?>

            </select>
    </p>
    <?php
    
    //Echo the user group
    ?>
    <p>
        <label for="project">I want access to group:<br />
            <select name="group" class="input">
                <option value="">Choose a group</option>
                <?php
                //Print all groups
                foreach($all_groups as $group){
                    echo "<option value=\"$group\"";
                    if($group == $pref_group_id) echo " selected ";
                    echo ">$group</option>";
                } 
                ?>

            </select>
    </p>
    <?php

      
    
    //Echo all fields
    foreach( $valid_options as $function => $display ) {
        //Determine type    
        $type = get_input_type($function);
        
        ?>
        <p>
            <label for="<?php echo $function;?>"><?php echo $display;?><br />
                <input type="<?php echo $type;?>" name="<?php echo $function;?>" id="<?php echo $function;?>" class="input" value="<?php echo esc_attr( wp_unslash( $data[$function] ) ); ?>" size="25" /></label>
        </p>
        <?php
    }
     
}

//Validated registration form
add_filter( 'registration_errors', 'custom_registration_errors', 10, 3 );

function custom_registration_errors( $errors, $sanitized_user_login, $user_email ) {
    
    //Import valid options
    global $valid_options;
    
    //Project confirmation
    if ( empty( $_POST['project'] ) || trim( $_POST['project'] ) == '' || is_int($_POST['project'])) {
        $errors->add( $value.'_error', '<strong>ERROR</strong>: You must choose a project');
    }
    
    //Validate $_POST data
    foreach( $_POST as $item => $value ) {
        if(array_key_exists($item, $valid_options)){
            if ( empty( $value ) || ! empty( $value ) && trim( $value ) == '' ) {
                $errors->add( $value.'_error', '<strong>ERROR</strong>: You must enter a '.$valid_options[$item]);
            }
        }
    }
    
    
    return $errors;
}

//Save new userdata
add_action( 'user_register', 'custom_user_register' );
function custom_user_register( $user_id ) {
    
    //Import valid options
    global $valid_options;
    
    //Save project
    if ( !empty( $_POST['project'] ) || trim( $_POST['project'] ) != '' || is_int($_POST['project'])) {
        update_user_meta( $user_id, 'pending_project',  $_POST['project']);
    }
    
    //Save group
    if ( !empty( $_POST['group'] ) || trim( $_POST['group'] ) != '') {
        update_user_meta( $user_id, 'pending_group',  $_POST['group']);
    }
    
    //Save $_POST data
    foreach( $_POST as $item => $value ) {
        if(array_key_exists($item, $valid_options)){
            if ( ! empty( $value ) ) {
                $value = sanitize_text_field($value);
                update_user_meta( $user_id, $item, trim( $value ) );
            }
        }
    }
}

//Override emails on new registration
if ( !function_exists('wp_new_user_notification') ) {    
  function wp_new_user_notification($user_id) {
      
        $project = new project;
        
        //Set globals
        global $wpdb, $wp_hasher;
        $user = get_userdata( $user_id );  
      
        //Send email to new user
      
        //Generate password retreive key and store in databasw
        $key = wp_generate_password( 20, false );
        do_action( 'retrieve_password_key', $user->user_login, $key );
        if ( empty( $wp_hasher ) ) {
            require_once ABSPATH . WPINC . '/class-phpass.php';
            $wp_hasher = new PasswordHash( 8, true );
        }
        $hashed = time() . ':' . $wp_hasher->HashPassword( $key );
        $wpdb->update( $wpdb->users, array( 'user_activation_key' => $hashed ), array( 'user_login' => $user->user_login ) );
        $username = $project->get_user_formal_name($user_id);  
      
        //Generate user message
        $message = "Dear ".$username.",\r\n\r\n";
        $message .= "Your new account is registered. Before you will be able to access the project files, your project manager will have to approve your request. When access is assigned you will be able to login and select your requested project.\r\n\r\n";
        $message .= "For now, please set your password:\r\n";
        $message .= '<' . network_site_url("wp-login.php?action=rp&key=$key&login=" . rawurlencode($user->user_login), 'login') . ">\r\n\r\n";
        wp_mail($user->user_email, 'Please finish your registration', $message);
      
        //Generate manager messafe
        $project_id = get_user_meta( $user_id, 'pending_project',  true);
        $group = get_user_meta( $user_id, 'pending_group',  true);
        if($group == '') $group = 'NOT SET';  
      
      
        $project_name = $project->get_project_name($project_id);
        $message = "A new user ({$username}) has registered and requires access to project: {$project_name} and group: {$group}.\r\n\r\n";
        $message .= "Please visit the link below to provide the user access.\r\n\r\n";
        $message .= network_site_url("wp-admin/post.php?post=".$project_id."&action=edit");
        wp_mail($project->get_project_managers_email($project_id), 'New registration for '.$project_name, $message);
      
  }    
}



?>

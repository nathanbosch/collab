<?php
////////////////////////////////////////////////////////////////////
//
//    Project: KNMI PMS 
//    Author: Nathan Bosch  
//    
//    Function: This file contains all possible functions for a 
//    public page.
//
////////////////////////////////////////////////////////////////////

class public_pages{
    private $project_id;
    
    function __construct(){
        $this->project_id = $_SESSION['current_project_id'];
    }
    
    function show(){
        //print opening
        echo "<div id='page'>";
        
        //Get page 
        $page_id = sanitize_text_field($_GET['page_id']);
        
        //Show single page
        if(isset($page_id) && $page_id != ''){
            $page = $this->get_public_page($page_id);
        }
        
        //Get first page
        else{
            $page = $this->get_public_page($this->get_public_pages()[0]);
        }
        
        //Print content
        echo $page['Content'];
        
        //Print closing
        echo "</div>";
    }
    
    function has_acces_to_public_page($page_id){
        $project_id = get_post_meta($page_id,'project_id',true);
        if($project_id == $_SESSION['current_project_id']) return true;
        else return false;
    }
    
    function get_public_pages(){
        //Get all pages
        $pages = $this->get_all_public_pages();
        $return = array();
        

        //Match page based on project id
        foreach($pages as $page){
            $page_project_id = get_post_meta($page, "project_id", true);
            if($page_project_id == $this->project_id) array_push($return, $page);
        }

        return $return;
    }

    function get_all_public_pages(){
        //Get existing pages
        $pages = get_posts(array('post_type' => 'public_pages','post_status' => 'publish', 'orderby' => 'Title', 'order' => 'ASC'));

        //Push ID to return
        $return = array();
        foreach($pages as $page){
            array_push($return, $page->ID);
        }

        //Remove possible duplicates
        $return = array_unique($return);
        return $return;
    }
    
    function get_public_page($page_id){
        //If page is accesible for this project
        if(!$this->has_acces_to_public_page($page_id)) return false;
        
        //Get page data
        $page_data = get_postdata($page_id);
        
        //Return empty results
        if($page_data['ID'] == '') return false;
        
        //Only allow for public pages
        if($page_data['post_type'] != 'public_pages') return false;
        
        $page_data['perma_link'] = home_url('public_pages/'.$page_id);        
        return $page_data;
    }
}
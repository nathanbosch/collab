    </div>
    <div id="clear"></div>
</body>
</html>
<?php wp_footer(); ?>
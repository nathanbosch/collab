<?php
//error_reporting(E_ALL);
//ini_set('display_errors','1');
//Require several plugins
if(!is_admin()){
    $required_plugins = array(  'knmi_pms' => 'See thesis or design document',
                                'bbpress' => 'https://nl.wordpress.org/plugins/bbpress/',
                                'custom-user-profile-photo' => 'https://nl.wordpress.org/plugins/custom-user-profile-photo/');
    
    $required_theme = "KNMI Project Management System theme";
    
    $missing_plugin_or_theme = false;
    
    
    //Check if plugin active
    foreach($required_plugins as $key => $required_plugin){
        
        if(strpos(implode(',',apply_filters( 'active_plugins', get_option( 'active_plugins' ))) , $key) === FALSE){
            echo "Please install the following plugin:<br/>{$key} - {$required_plugin}<br/><br/><br/>";
            $missing_plugin_or_theme = true;
        }
        
    }
    
    //Check if theme active
    if(get_option('current_theme') != $required_theme){
        echo "Please install the following theme:<br/>{$required_theme} - See thesis or design document<br/><br/><br/>";
        $missing_plugin_or_theme = true;
    }
    
    if($missing_plugin_or_theme) exit;
    
}
add_action( 'wp_before_admin_bar_render', 'customize_admin_bar' );


//Remove Wordpress logo from login screen
function custom_logo() { ?>
    <style type="text/css">
        #login h1 a, .login h1 a {
            display:none;
        }
    </style>
<?php }
add_action( 'login_enqueue_scripts', 'custom_logo' );

//Disable default dashboard widgets
function disable_default_dashboard_widgets() {
    remove_meta_box('dashboard_right_now', 'dashboard', 'core');
	remove_meta_box('dashboard_activity', 'dashboard', 'core');
	remove_meta_box('dashboard_recent_comments', 'dashboard', 'core');
	remove_meta_box('dashboard_incoming_links', 'dashboard', 'core');
	remove_meta_box('dashboard_plugins', 'dashboard', 'core');
	remove_meta_box('bbp-dashboard-right-now', 'dashboard', 'core');
    remove_meta_box('dashboard_quick_press', 'dashboard', 'core');
	remove_meta_box('dashboard_recent_drafts', 'dashboard', 'core');
	remove_meta_box('dashboard_primary', 'dashboard', 'core');
	remove_meta_box('dashboard_secondary', 'dashboard', 'core');
}
add_action('admin_menu', 'disable_default_dashboard_widgets');
remove_action( 'welcome_panel', 'wp_welcome_panel' );

//Support thumbs for posts
add_theme_support( 'post-thumbnails' ); 

function customize_admin_bar() {
    global $wp_admin_bar;
	
	if (!class_exists('project')) {
		return;
	}
    
    $project = new project;
    $current_project_id = $project->get_current_project_id();

    //Remove WordPress default items
    $wp_admin_bar->remove_menu('wp-logo'); 
    $wp_admin_bar->remove_menu('edit'); 
    $wp_admin_bar->remove_menu('customize'); 
    $wp_admin_bar->remove_menu('site-name'); 
    $wp_admin_bar->remove_menu('comments'); 
    $wp_admin_bar->remove_menu('new-content'); 
    $wp_admin_bar->remove_menu('my-account'); 
    $wp_admin_bar->remove_menu('view'); 
    $wp_admin_bar->remove_menu('search'); 
    
    //Get user details
    $role = $project->get_project_role();
    $groups = implode(', ',$project->get_project_groups());
    
    //Define menu items arguments
    $current_user = array(
                    'id' => 'current_user',
                    'title' => 'Current user: '.$project->get_user_formal_name()
                );
    
    $current_project = array(
                    'id' => 'current_project',
                    'title' => 'Current project: '.$project->get_project_name($current_project_id),
                    'href' => '/?change_project'
                );
    
    $project_role = array(
                    'id' => 'project_role',
                    'title' => 'Role: '.$role
                );
    
    $project_group = array(
                    'id' => 'project_group',
                    'title' => 'Groups: '.$groups
                );
    $user = new WP_User( get_current_user_id() );
    $wordpress_role = array(
                    'id' => 'wordpress_role',
                    'title' => 'Wordpress role: '.implode(',',$user->roles)
                );
    
    $log_out = array(
                    'id' => 'log_out',
                    'title' => 'Logout',
                    'href' => wp_logout_url(),
		            'meta'  => array( 'class' => 'admin_bar_right' )
                );
    
    $back_end = array(
                    'id' => 'back_end',
                    'title' => 'Goto back-end',
                    'href' => '/wp-admin',
                    'meta'  => array( 'class' => 'admin_bar_right' )
                );
    
    $front_end = array(
                    'id' => 'front_end',
                    'title' => 'Goto front-end',
                    'href' => '/',
                    'meta'  => array( 'class' => 'admin_bar_right' )
                );
    
    //Add menu items
    $wp_admin_bar->add_node($current_user);
    $wp_admin_bar->add_node($current_project);
    $wp_admin_bar->add_node($project_role);
    $wp_admin_bar->add_node($project_group);
    //$wp_admin_bar->add_node($wordpress_role); //Usefull for debugging
    $wp_admin_bar->add_node($log_out);
    
    if(is_admin()){
        $wp_admin_bar->add_node($front_end);
    }
    else{
        $wp_admin_bar->add_node($back_end);
    }
}





?>

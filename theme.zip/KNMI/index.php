<?php 

include(ABSPATH.'wp-content/plugins/knmi_pms/classes.php');
//Disable error messages
require_once(ABSPATH . 'wp-settings.php');
error_reporting(0);

//Filtering ALL POST AND GET
$_GET   = filter_input_array(INPUT_GET, FILTER_SANITIZE_STRING);
$_POST  = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
//Filtering ALL POST AND GET

$project = new project;
$pp = new public_pages;
$project_id = $project->get_current_project_id();
$page = sanitize_text_field($_GET['page']);

$errors = array();

//Empty pages redirect
if($page == ''){
    $page = 'public_pages';
 $var = $pp->get_public_pages();
   if(!$project->project_has_module(null,$page) or empty($var)){
        $page = $project->get_project_modules()[0];
    }
}

//Validate requested module
$valid_modules = unserialize(get_option('knmi_modules', true));
if(!array_key_exists($page, $valid_modules)){
    array_push($errors, 'Invalid module');
}

//Check if project has module
if(!$project->project_has_module(null,$page)){
    array_push($errors, 'The requested module is not supported for this project.');
}

//Check if have access to requested module
$minimal_roles = unserialize(get_option('knmi_module_minimal_role', true));
if(is_user_logged_in() && !$project->role_grater_than($project->get_project_role(),$minimal_roles[$page])){
    array_push($errors, 'You have no access to this module');
}

//Redirect about to project page.
if($page == 'about' && !(substr($_SERVER['REQUEST_URI'], 0, strlen('/project')) === '/project')){
	wp_redirect(get_permalink($_SESSION['current_project_id']));
	exit;
}
//Begin header here to enable wp_redirect
get_header(); 

$news = new news;
$ra = new recent_activities;
$fb = new file_browser;
$calendar = new calendar;

//Echo errors
if(!empty($errors)){
    $continue = false;
    echo "<div id='page' class='error'>";
    foreach($errors as $error){
        echo "<span class='message'>{$error}</span>";
    }
    echo "</div>";
}
else{
    $continue = true;
}

if($page && $continue){
    
    switch ($page){
            
        case 'discussion':
            $bbpress_shortcodes = new BBP_Shortcodes;
            $attr['id'] = $project->get_forum_id();
            echo $bbpress_shortcodes->display_forum($attr);
            break;
            
        case 'news':
            $news->show();
            break;
            
        case 'recent_activities';
            $ra->show();
            break;
            
        case 'contacts':
            $project->show_contacts();
            break;
            
        case 'calendar':
            $calendar->show();
            break;
            
        case 'file_browser':
            $fb->show();
            break;
            
        case 'public_pages':
            $pp->show();
            break;
            
        default:
            break;
    }
}
        
get_footer(); 


?>

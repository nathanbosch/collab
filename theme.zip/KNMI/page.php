<?php get_header();
while ( have_posts() ) : the_post();
    echo "<div id='project_page'>";
        the_content();
    echo "</div>";
endwhile;
get_footer(); ?>
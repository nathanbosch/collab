<!DOCTYPE html>
<html <?php language_attributes(); ?> >
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
    <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/font-awesome.min.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/style.css" media="screen" />
   
    
	<?php wp_head(); ?>
</head>
<body>
    <div id="aside">
        <a href="<?php echo home_url();?>"><?php echo get_the_post_thumbnail($_SESSION['current_project_id'], 'full', array('class'=>'project_logo')); ?></a>
        <ul id="menu">
            <li class="fa fa-th"><a href="/?change_project">Choose other project</a></li>
            <?php
            //Login/out button
                if(is_user_logged_in()){
                    $url = wp_logout_url();
                    echo "<li class='fa fa-sign-out'><a href='{$url}'>Logout</a></li>";
                }
                else{
                    $url = wp_login_url();
                    echo "<li class='fa fa-sign-in'><a href='{$url}'>Login</a></li>";
                    $url = wp_registration_url();
                    echo "<li class='fa fa-pencil'><a href='{$url}'>Register</a></li>";
                }
        ?>
           
        </ul>
        <ul id="menu">
            <?php 
            
            $project = new project;
            
                //Print public pages, if enabled
                if($project->project_has_module(null, 'public_pages') && (is_user_logged_in() or $project->module_login_required(null, 'public_pages') == 'false')){
                    
                    $pp = new public_pages;
                    foreach($pp->get_public_pages() as $page_id){
                        $page = $pp->get_public_page($page_id);
                        echo "<li class=''><a href='{$page['perma_link']}'>{$page['Title']}</a></li>";
                    }
                    
                    echo "</ul>";
                    echo "<ul id='menu'>";
                }
            
                $modules = $project->get_project_modules($_SESSION['current_project_id']);
            
                if(!empty($modules)){
                
                    foreach($modules as $module){

                        //Check if correct to access page.
                        if($project->module_login_required(null, $module) == 'true'){
                            $minimal_roles = unserialize(get_option('knmi_module_minimal_role', true));
                            if(!$project->role_grater_than($project->get_project_role(),$minimal_roles[$module])){
                                continue;
                            }
                        }

                        switch($module){
                            case 'about':
                                $class = 'fa-home';
                                break;
                            case 'calendar':
                                $class = 'fa-calendar';
                                break;
                            case 'contacts':
                                $class = 'fa-users';
                                break;
                            case 'discussion':
                                $class = 'fa-comments-o';
                                break;
                            case 'file_browser':
                                $class = 'fa-files-o';
                                break;
                            case 'news':
                                $class = 'fa-newspaper-o';
                                break;
                            case 'recent_activities':
                                $class = 'fa-list';
                                break;
                            case 'public_pages':
                                continue 2;
                                break;
                            default:
                                $class = '';
                                break;
                        }

                        echo '<li class="fa '.$class.'"><a href="/'.$module.'">'.$project->get_module_full_name($module).'</a></li>';

                    } 
                }
            ?>
        </ul>
        </div>
    <div id="content">